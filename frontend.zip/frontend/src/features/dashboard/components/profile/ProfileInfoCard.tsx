"use client";

import React from "react";

import { Profile } from "@/types/profile";

interface ProfileInfoCardProps {
  profile: Profile | null;
  onEdit: () => void;
}

export default function ProfileInfoCard({ profile, onEdit }: ProfileInfoCardProps) {
  const initials = profile?.full_name 
    ? profile.full_name.split(' ').map((n: string) => n[0]).join('').toUpperCase().substring(0, 2)
    : "NA";

  return (
    <div className="relative bg-white rounded-2xl p-6 sm:p-8 shadow-sm mb-6 overflow-hidden border border-slate-200">
      <div className="relative flex flex-col md:flex-row items-center md:items-start gap-6 lg:gap-10">
        {/* Avatar Section */}
        <div className="relative shrink-0">
          <div className="w-32 h-40 sm:w-36 sm:h-44 rounded-2xl bg-white p-1 shadow-sm overflow-hidden group border border-slate-100">
            <div className="w-full h-full bg-slate-100 rounded-xl flex items-center justify-center overflow-hidden">
              {profile?.profile_photo_url ? (
                <img src={profile.profile_photo_url} alt={profile.full_name} className="w-full h-full object-cover transition-all duration-700 group-hover:scale-105" />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-slate-700 to-slate-900 flex items-center justify-center text-white text-3xl font-bold">
                  {initials}
                </div>
              )}
            </div>
          </div>
          <button className="absolute -bottom-2 -right-2 w-10 h-10 bg-white rounded-lg shadow border border-slate-200 flex items-center justify-center text-slate-600 hover:bg-slate-50 hover:text-slate-900 transition-all transform hover:scale-105 active:scale-95 group/btn">
            <span className="material-symbols-outlined text-xl font-bold">photo_camera</span>
          </button>
        </div>
 
        {/* Info Section */}
        <div className="flex-1 min-w-0 w-full">
          <div className="text-center md:text-left mb-6">
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight mb-2 leading-tight break-words">{profile?.full_name || "Alex Thompson"}</h1>
            <p className="text-sm sm:text-base font-medium text-slate-500 leading-snug break-words">
               {profile?.current_designation || "Senior Product Designer"} <span className="text-slate-400 font-light mx-1">at</span> <span className="text-indigo-600 font-semibold">{profile?.current_company || "Google"}</span>
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-2 2xl:grid-cols-4 gap-4 mb-6">
             <div className="flex items-center gap-3 text-xs font-medium text-slate-600 min-w-0">
                <div className="w-8 h-8 shrink-0 rounded-lg bg-slate-50 flex items-center justify-center text-slate-400 border border-slate-200/50">
                   <span className="material-symbols-outlined text-base">phone_iphone</span>
                </div>
                <span className="break-all">{profile?.phone || "(05) 323 7289"}</span>
             </div>
             <div className="flex items-center gap-3 text-xs font-medium text-slate-600 min-w-0">
                <div className="w-8 h-8 shrink-0 rounded-lg bg-slate-50 flex items-center justify-center text-slate-400 border border-slate-200/50">
                   <span className="material-symbols-outlined text-base">mail</span>
                </div>
                <span className="break-all">{profile?.email || "ems@gmail.com"}</span>
             </div>
             <div className="flex items-center gap-3 text-xs font-medium text-slate-600 min-w-0">
                <div className="w-8 h-8 shrink-0 rounded-lg bg-slate-50 flex items-center justify-center text-slate-400 border border-slate-200/50">
                   <span className="material-symbols-outlined text-base">link</span>
                </div>
                <span className="break-all">{profile?.social_links?.portfolio || "Portfolio URL"}</span>
             </div>
             <div className="flex items-center gap-3 text-xs font-medium text-slate-600 min-w-0">
                <div className="w-8 h-8 shrink-0 rounded-lg bg-slate-50 flex items-center justify-center text-slate-400 border border-slate-200/50">
                   <span className="material-symbols-outlined text-base">public</span>
                </div>
                <span className="break-all">{profile?.social_links?.linkedin || "LinkedIn"}</span>
             </div>
          </div>

          <button 
            onClick={onEdit}
            className="w-full md:w-auto px-6 bg-slate-50 hover:bg-slate-100 text-slate-700 font-semibold text-xs py-2.5 rounded-lg border border-slate-200 transition-all flex items-center justify-center gap-2 group"
          >
            Edit Personal Info
            <span className="material-symbols-outlined text-xs transition-transform group-hover:translate-x-1">arrow_forward</span>
          </button>
        </div>
      </div>

      {/* Stats Row */}
      <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 mt-6 pt-6 border-t border-slate-100">
         <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-50 text-slate-700 rounded-lg font-medium text-xs border border-slate-200 transition-all hover:bg-slate-100">
            <span className="material-symbols-outlined text-base shrink-0">work_history</span>
            {profile?.experience_years ? `${profile.experience_years}+ Yrs` : "Fresher"}
         </div>
         <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-50 text-slate-700 rounded-lg font-medium text-xs border border-slate-200 transition-all hover:bg-slate-100">
            <span className="material-symbols-outlined text-base shrink-0">stars</span>
            {profile?.projects?.length || 0} Projects
         </div>
         <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-50 text-slate-700 rounded-lg font-medium text-xs border border-slate-200 transition-all hover:bg-slate-100">
            <span className="material-symbols-outlined text-base shrink-0">verified</span>
            {profile?.certifications?.length || 0} Certs
         </div>
         <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-50 text-slate-700 rounded-lg font-medium text-xs border border-slate-200 transition-all hover:bg-slate-100">
            <span className="material-symbols-outlined text-base shrink-0">location_on</span>
            {profile?.location || "Remote"}
         </div>
      </div>
    </div>
  );
}
