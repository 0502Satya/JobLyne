"use client";

import React, { useState } from "react";
import { Education } from "@/types/profile";

interface EducationSectionProps {
  data: Education[];
  onChange: (data: Education[]) => void;
  isExpanded?: boolean;
  onToggleExpand?: () => void;
}

const FAMOUS_UNIVERSITIES = [
  "Harvard University",
  "Stanford University",
  "Massachusetts Institute of Technology (MIT)",
  "University of Oxford",
  "University of Cambridge",
  "University of Toronto",
  "University of British Columbia",
  "McGill University",
  "Indian Institute of Technology (IIT)",
  "Delhi University",
  "University of Waterloo",
];

export default function EducationSection({ data = [], onChange, isExpanded = false, onToggleExpand }: EducationSectionProps) {
  const [education, setEducation] = useState<Education[]>(data);
  const [showSuggestions, setShowSuggestions] = useState<{ [key: string]: boolean }>({});

  React.useEffect(() => {
    setEducation(data);
  }, [data]);

  const addEntry = () => {
    const newEntry: Education = {
      id: Date.now().toString(),
      school: "",
      degree: "",
      field: "",
      start_year: "",
      end_year: "",
      grade: "",
      description: "",
      certifications: "",
    };
    const updated = [...education, newEntry];
    setEducation(updated);
    onChange(updated);
  };

  const removeEntry = (id?: string | number) => {
    if (!id) return;
    const updated = education.filter((e) => e.id !== id);
    setEducation(updated);
    onChange(updated);
  };

  const updateEntry = (id: string | number | undefined, field: keyof Education, value: any) => {
    if (!id) return;
    const updated = education.map((e) => (e.id === id ? { ...e, [field]: value } : e));
    setEducation(updated);
    onChange(updated);
  };

  const moveEntry = (index: number, direction: "up" | "down") => {
    const updated = [...education];
    const targetIndex = direction === "up" ? index - 1 : index + 1;
    if (targetIndex >= 0 && targetIndex < updated.length) {
      const temp = updated[index];
      updated[index] = updated[targetIndex];
      updated[targetIndex] = temp;
      setEducation(updated);
      onChange(updated);
    }
  };

  const isComplete = education.length > 0;

  return (
    <section className="bg-white rounded-2xl border border-slate-200/80 shadow-sm transition-all duration-300 overflow-hidden" id="education">
      {/* Collapsible Header */}
      <button
        type="button"
        onClick={onToggleExpand}
        className="w-full flex items-center justify-between p-5 text-left hover:bg-slate-50/50 transition-colors focus:outline-none focus:ring-2 focus:ring-primary/20 cursor-pointer"
        aria-expanded={isExpanded}
      >
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-primary/5 flex items-center justify-center text-primary shrink-0">
            <span className="material-symbols-outlined text-xl">school</span>
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-800 leading-tight">Education</h3>
            <p className="text-xs text-slate-500 mt-0.5">Add your degrees and study fields</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {isComplete ? (
            <span className="px-2.5 py-0.5 bg-emerald-50 text-emerald-600 text-xs font-semibold rounded-full flex items-center gap-1 border border-emerald-100/50">
              <span className="material-symbols-outlined text-sm font-bold">check_circle</span>
              {education.length} {education.length === 1 ? "Degree" : "Degrees"}
            </span>
          ) : (
            <span className="px-2.5 py-0.5 bg-amber-50 text-amber-700 text-xs font-semibold rounded-full border border-amber-100/50 animate-pulse">
              Required
            </span>
          )}
          <span className={`material-symbols-outlined text-slate-400 transition-transform ${isExpanded ? "rotate-180" : ""}`}>
            expand_more
          </span>
        </div>
      </button>

      {/* Expanded Content */}
      <div
        className={`transition-all duration-500 ease-in-out overflow-hidden ${
          isExpanded ? "max-h-[2500px] opacity-100 border-t border-slate-100" : "max-h-0 opacity-0 pointer-events-none"
        }`}
      >
        <div className="p-5 sm:p-6 bg-white space-y-6">
          <div className="flex justify-end">
            <button
              onClick={addEntry}
              type="button"
              className="px-4 py-2 bg-primary/5 text-primary text-xs font-bold rounded-lg hover:bg-primary hover:text-white transition-all border border-primary/10 flex items-center justify-center gap-1.5 min-h-[44px] cursor-pointer"
            >
              <span className="material-symbols-outlined text-sm">add</span>
              Add Education
            </button>
          </div>

          <div className="space-y-8">
            {education.length === 0 ? (
              <div className="text-center py-10 border border-dashed border-slate-205 rounded-xl bg-slate-50/50">
                <span className="material-symbols-outlined text-3xl text-slate-350 mb-2 block">history_edu</span>
                <span className="text-sm font-bold text-slate-700 block mb-0.5">No education entries yet</span>
                <span className="text-xs text-slate-500 block mb-4">Adding qualification helps recruiters verify your credentials.</span>
                <button
                  type="button"
                  onClick={addEntry}
                  className="text-primary text-xs font-bold hover:underline cursor-pointer min-h-[44px] px-4"
                >
                  Add first degree card
                </button>
              </div>
            ) : (
              education.map((edu, idx) => {
                const filteredSuggestions = FAMOUS_UNIVERSITIES.filter((uni) =>
                  uni.toLowerCase().includes((edu.school || "").toLowerCase())
                );

                return (
                  <div
                    key={edu.id}
                    className="relative bg-slate-50/30 hover:bg-slate-50/70 border border-slate-205 rounded-xl p-5 transition-all group"
                  >
                    {/* Actions */}
                    <div className="absolute top-3 right-3 flex items-center gap-1.5 opacity-100 lg:opacity-0 lg:group-hover:opacity-100 transition-opacity">
                      <button
                        type="button"
                        disabled={idx === 0}
                        onClick={() => moveEntry(idx, "up")}
                        className="w-11 h-11 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-500 hover:text-primary disabled:opacity-30 cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-base">arrow_upward</span>
                      </button>
                      <button
                        type="button"
                        disabled={idx === education.length - 1}
                        onClick={() => moveEntry(idx, "down")}
                        className="w-11 h-11 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-500 hover:text-primary disabled:opacity-30 cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-base">arrow_downward</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => removeEntry(edu.id)}
                        className="w-11 h-11 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-red-500 hover:text-red-700 hover:bg-red-50 cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-base">delete</span>
                      </button>
                    </div>

                    <div className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="relative">
                          <label className="block text-xs font-semibold text-slate-500 mb-1">School / University</label>
                          <input
                            type="text"
                            value={edu.school || ""}
                            onChange={(e) => {
                              updateEntry(edu.id, "school", e.target.value);
                              setShowSuggestions((prev) => ({ ...prev, [edu.id as string]: true }));
                            }}
                            onFocus={() => setShowSuggestions((prev) => ({ ...prev, [edu.id as string]: true }))}
                            onBlur={() => setTimeout(() => setShowSuggestions((prev) => ({ ...prev, [edu.id as string]: false })), 200)}
                            placeholder="e.g. Stanford University"
                            className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                          />
                          {showSuggestions[edu.id as string] && filteredSuggestions.length > 0 && edu.school && (
                            <div className="absolute z-10 w-full bg-white border border-slate-200 rounded-lg shadow-md mt-1 max-h-48 overflow-y-auto">
                              {filteredSuggestions.map((uni) => (
                                <button
                                  key={uni}
                                  type="button"
                                  onClick={() => {
                                    updateEntry(edu.id, "school", uni);
                                    setShowSuggestions((prev) => ({ ...prev, [edu.id as string]: false }));
                                  }}
                                  className="w-full text-left px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
                                >
                                  {uni}
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">Degree</label>
                          <input
                            type="text"
                            value={edu.degree || ""}
                            onChange={(e) => updateEntry(edu.id, "degree", e.target.value)}
                            placeholder="e.g. Bachelor of Science"
                            className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div className="md:col-span-2">
                          <label className="block text-xs font-semibold text-slate-500 mb-1">Field of Study</label>
                          <input
                            type="text"
                            value={edu.field || ""}
                            onChange={(e) => updateEntry(edu.id, "field", e.target.value)}
                            placeholder="e.g. Computer Science"
                            className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">Start Year</label>
                          <input
                            type="number"
                            value={edu.start_year || ""}
                            onChange={(e) => updateEntry(edu.id, "start_year", e.target.value)}
                            placeholder="2018"
                            className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">End Year (or Expected)</label>
                          <input
                            type="number"
                            value={edu.end_year || ""}
                            onChange={(e) => updateEntry(edu.id, "end_year", e.target.value)}
                            placeholder="2022"
                            className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">Grade / GPA / Percentage</label>
                          <input
                            type="text"
                            value={edu.grade || ""}
                            onChange={(e) => updateEntry(edu.id, "grade", e.target.value)}
                            placeholder="e.g. 3.8/4.0 or 85%"
                            className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                          />
                        </div>
                        <div className="md:col-span-2">
                          <label className="block text-xs font-semibold text-slate-500 mb-1">Courses & Activities</label>
                          <input
                            type="text"
                            value={edu.certifications || ""}
                            onChange={(e) => updateEntry(edu.id, "certifications", e.target.value)}
                            placeholder="e.g. Algorithms, Data Structures, Varsity Football"
                            className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="block text-xs font-semibold text-slate-500">Degree Description</label>
                        <textarea
                          value={edu.description || ""}
                          onChange={(e) => updateEntry(edu.id, "description", e.target.value)}
                          rows={3}
                          placeholder="Summarize your academic focus, thesis, or major milestones..."
                          className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3.5 text-sm font-medium text-slate-700 focus:border-primary focus:ring-1 focus:ring-primary/20 outline-none leading-relaxed resize-none placeholder:text-slate-400"
                        />
                      </div>
                    </div>
                  </div>
                );
              })
            )}

            {/* Fresh Graduate Tip */}
            <div className="flex items-start gap-3 p-4 bg-slate-50 border border-slate-200 rounded-xl">
              <span className="material-symbols-outlined text-primary font-bold mt-0.5">school</span>
              <div className="text-xs text-slate-600 leading-normal">
                <span className="font-bold block mb-0.5">Freshers & student tips</span>
                Highlight key academic projects, hackathon achievements, and major course topics to capture entry level recruiter attention.
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
