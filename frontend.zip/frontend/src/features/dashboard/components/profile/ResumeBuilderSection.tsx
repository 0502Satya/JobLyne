"use client";

import React, { useState } from "react";
import { Profile } from "@/types/profile";

interface ResumeBuilderSectionProps {
  profile: Profile | null;
  onChange: <K extends keyof Profile>(field: K, value: Profile[K]) => void;
  isExpanded?: boolean;
  onToggleExpand?: () => void;
}

export default function ResumeBuilderSection({ profile, onChange, isExpanded = false, onToggleExpand }: ResumeBuilderSectionProps) {
  const [template, setTemplate] = useState("classic");

  // Calculate simulated Profile Strength score based on profile completion with no baseline floor (starts at 0%)
  const getProfileStrengthScore = () => {
    let score = 0;
    if (profile?.bio) score += 20;
    if (profile?.experience && profile.experience.length > 0) score += 25;
    if (profile?.education && profile.education.length > 0) score += 20;
    if (profile?.skills && profile.skills.length >= 5) score += 20;
    if (profile?.resume_file_url) score += 15;
    return Math.min(score, 100);
  };

  const profileStrength = getProfileStrengthScore();

  const handleDownloadPDF = () => {
    window.open("/dashboard/resume-preview?print=true", "_blank");
  };

  const handleLivePreview = () => {
    window.open("/dashboard/resume-preview", "_blank");
  };

  const isComplete = !!profile?.resume_file_url;

  return (
    <section className="bg-white rounded-2xl border border-slate-200/80 shadow-sm transition-all duration-300 overflow-hidden" id="resume">
      {/* Collapsible Header */}
      <button
        type="button"
        onClick={onToggleExpand}
        className="w-full flex items-center justify-between p-5 text-left hover:bg-slate-50/50 transition-colors focus:outline-none focus:ring-2 focus:ring-primary/20 cursor-pointer"
        aria-expanded={isExpanded}
      >
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-primary/5 flex items-center justify-center text-primary shrink-0">
            <span className="material-symbols-outlined text-xl">analytics</span>
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-800 leading-tight">Resume Builder & Strength</h3>
            <p className="text-xs text-slate-500 mt-0.5">Auto-generate and optimize your CV</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <span className="px-2.5 py-0.5 bg-indigo-50 text-indigo-700 text-xs font-semibold rounded-full border border-indigo-100/50">
            Strength: {profileStrength}%
          </span>
          <span className={`material-symbols-outlined text-slate-400 transition-transform ${isExpanded ? "rotate-180" : ""}`}>
            expand_more
          </span>
        </div>
      </button>

      {/* Expanded Content */}
      <div
        className={`transition-all duration-500 ease-in-out overflow-hidden ${
          isExpanded ? "max-h-[2500px] opacity-100 border-t border-slate-100" : "max-h-0 opacity-0 pointer-events-none"
        }`}
      >
        <div className="p-5 sm:p-6 bg-white space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-[1fr_240px] gap-6">
            {/* Templates Selection & Resume Details */}
            <div className="space-y-5 min-w-0">
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2.5">Select Template</h4>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { id: "classic", label: "Classic", color: "bg-slate-700" },
                    { id: "modern", label: "Modern", color: "bg-primary" },
                    { id: "minimal", label: "Minimalist", color: "bg-slate-500" },
                  ].map((tmpl) => (
                    <button
                      key={tmpl.id}
                      onClick={() => setTemplate(tmpl.id)}
                      type="button"
                      className={`flex flex-col items-center justify-center p-2.5 rounded-lg border-2 transition-all cursor-pointer ${
                        template === tmpl.id
                          ? "border-primary bg-white shadow-sm"
                          : "border-transparent bg-slate-100 hover:bg-slate-200/50"
                      }`}
                    >
                      <div className={`w-8 h-10 rounded shadow-inner mb-1.5 ${tmpl.color} opacity-80 flex items-center justify-center text-white text-[8px] font-bold`}>
                        CV
                      </div>
                      <span className="text-[11px] font-semibold text-slate-700">{tmpl.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2.5">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Optimization Recommendations</h4>
                <div className="space-y-2">
                  {(!profile?.skills || profile.skills.length < 5) && (
                    <div className="flex items-start gap-2 text-xs text-amber-705 font-semibold bg-amber-50/50 p-3 rounded-lg border border-amber-100">
                      <span className="material-symbols-outlined text-sm mt-0.5">info</span>
                      Add at least 5 skills to showcase your core competencies.
                    </div>
                  )}
                  {(!profile?.experience || profile.experience.length === 0) && (
                    <div className="flex items-start gap-2 text-xs text-amber-705 font-semibold bg-amber-50/50 p-3 rounded-lg border border-amber-100">
                      <span className="material-symbols-outlined text-sm mt-0.5">info</span>
                      Add work experience records to highlight your career history.
                    </div>
                  )}
                  {profileStrength >= 80 && (
                    <div className="flex items-start gap-2 text-xs text-emerald-650 font-semibold bg-emerald-50/50 p-3 rounded-lg border border-emerald-100">
                      <span className="material-symbols-outlined text-sm mt-0.5">stars</span>
                      Looking good! Your profile has excellent detail and strength.
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Action Widgets */}
            <div className="flex flex-col justify-between gap-5 border-t lg:border-t-0 lg:border-l border-slate-200/60 pt-5 lg:pt-0 lg:pl-5">
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Actions</h4>
                <button
                  onClick={handleDownloadPDF}
                  type="button"
                  className="w-full py-2.5 bg-primary text-white font-bold text-xs rounded-lg hover:bg-primary/95 transition-all shadow-sm flex items-center justify-center gap-1.5 min-h-[44px] cursor-pointer"
                >
                  <span className="material-symbols-outlined text-sm">print</span>
                  Print / Save PDF
                </button>
                <button
                  onClick={handleLivePreview}
                  type="button"
                  className="w-full py-2.5 bg-slate-50 text-slate-700 border border-slate-200 font-bold text-xs rounded-lg hover:bg-slate-100 transition-all flex items-center justify-center gap-1.5 min-h-[44px] cursor-pointer"
                >
                  <span className="material-symbols-outlined text-sm">visibility</span>
                  Live Preview
                </button>
              </div>

              <div className="bg-slate-50 p-3.5 rounded-lg text-xs text-slate-500 font-medium leading-relaxed border border-slate-200">
                <span className="font-bold text-slate-750 uppercase block mb-0.5">Print Tip</span>
                Use the browser print window to save as PDF. Ensure &quot;Background graphics&quot; is checked in print settings.
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
