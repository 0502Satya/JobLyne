"use client";

import React, { useState } from "react";
import { Profile } from "@/types/profile";

interface JobPreferencesSectionProps {
  data: Profile;
  onChange: <K extends keyof Profile>(field: K, value: Profile[K]) => void;
  isExpanded?: boolean;
  onToggleExpand?: () => void;
}

export default function JobPreferencesSection({ data, onChange, isExpanded = true, onToggleExpand }: JobPreferencesSectionProps) {
  const [locInput, setLocInput] = useState("");

  const workModes = ["Remote", "Hybrid", "On-site"];
  const companySizes = ["Startup (<50)", "Mid-size (50-500)", "Enterprise (>500)", "No preference"];

  // Helper to safely parse preferred locations
  const getPreferredLocations = (): string[] => {
    if (!data.preferred_locations) return [];
    if (Array.isArray(data.preferred_locations)) return data.preferred_locations;
    try {
      const parsed = JSON.parse(data.preferred_locations);
      if (Array.isArray(parsed)) return parsed;
    } catch (e) {}
    if (typeof data.preferred_locations === "string") {
      return data.preferred_locations.split(",").map((l) => l.trim()).filter(Boolean);
    }
    return [];
  };

  const locations = getPreferredLocations();

  const handleToggleWorkMode = (mode: string) => {
    let current: string[] = [];
    if (Array.isArray(data.work_mode)) {
      current = data.work_mode;
    } else if (typeof data.work_mode === "string") {
      try {
        current = JSON.parse(data.work_mode);
      } catch (e) {
        current = data.work_mode.split(",").map((m) => m.trim()).filter(Boolean);
      }
    }
    const updated = current.includes(mode)
      ? current.filter((m) => m !== mode)
      : [...current, mode];
    onChange("work_mode", updated);
  };

  const handleAddLocation = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      const val = locInput.trim();
      if (val && !locations.includes(val)) {
        const updated = [...locations, val];
        onChange("preferred_locations", updated);
      }
      setLocInput("");
    }
  };

  const handleRemoveLocation = (loc: string) => {
    const updated = locations.filter((l) => l !== loc);
    onChange("preferred_locations", updated);
  };

  const isComplete = !!(data.desired_titles && data.expected_salary);

  return (
    <section className="bg-white rounded-2xl border border-slate-200/80 shadow-sm transition-all duration-300 overflow-hidden" id="preferences">
      {/* Collapsible Header */}
      <button
        type="button"
        onClick={onToggleExpand}
        className="w-full flex items-center justify-between p-5 text-left hover:bg-slate-50/50 transition-colors focus:outline-none focus:ring-2 focus:ring-primary/20 cursor-pointer"
        aria-expanded={isExpanded}
      >
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-primary/5 flex items-center justify-center text-primary shrink-0">
            <span className="material-symbols-outlined text-xl">tune</span>
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-800 leading-tight">Job Preferences</h3>
            <p className="text-xs text-slate-500 mt-0.5">Define your ideal career opportunities</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {isComplete ? (
            <span className="px-2.5 py-0.5 bg-emerald-50 text-emerald-600 text-xs font-semibold rounded-full flex items-center gap-1 border border-emerald-100/50">
              <span className="material-symbols-outlined text-sm font-bold">check_circle</span>
              Complete
            </span>
          ) : (
            <span className="px-2.5 py-0.5 bg-amber-50 text-amber-700 text-xs font-semibold rounded-full border border-amber-100/50 animate-pulse">
              Required
            </span>
          )}
          <span className={`material-symbols-outlined text-slate-400 transition-transform ${isExpanded ? "rotate-180" : ""}`}>
            expand_more
          </span>
        </div>
      </button>

      {/* Expanded Content */}
      <div
        className={`transition-all duration-500 ease-in-out overflow-hidden ${
          isExpanded ? "max-h-[2500px] opacity-100 border-t border-slate-100" : "max-h-0 opacity-0 pointer-events-none"
        }`}
      >
        <div className="p-5 sm:p-6 bg-white space-y-6">
          {/* Desired Titles */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5">Desired Job Roles</label>
            <input
              type="text"
              value={data.desired_titles || ""}
              onChange={(e) => onChange("desired_titles", e.target.value)}
              placeholder="e.g. Senior Product Manager, Technical Lead"
              className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
            />
            <span className="text-xs text-slate-500 block mt-1">Separate multiple titles with commas</span>
          </div>

          {/* Expected & Current Salaries */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5">Expected Salary (Annual)</label>
              <div className="relative">
                <span className="absolute left-3 top-2 text-slate-400 text-sm font-medium">{data.currency || "$"}</span>
                <input
                  type="text"
                  value={data.expected_salary || ""}
                  onChange={(e) => onChange("expected_salary", e.target.value)}
                  placeholder="120,000"
                  className="w-full pl-8 pr-4 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5">Current CTC / Salary</label>
              <div className="relative">
                <span className="absolute left-3 top-2 text-slate-400 text-sm font-medium">{data.currency || "$"}</span>
                <input
                  type="text"
                  value={data.current_salary || ""}
                  onChange={(e) => onChange("current_salary", e.target.value)}
                  placeholder="95,000"
                  className="w-full pl-8 pr-4 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5">Notice Period</label>
              <select
                value={data.notice_period || ""}
                onChange={(e) => onChange("notice_period", e.target.value)}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700"
              >
                <option value="">Select Notice Period</option>
                <option value="Immediate">Immediate</option>
                <option value="15 Days">15 Days</option>
                <option value="1 Month">1 Month</option>
                <option value="2 Months">2 Months</option>
                <option value="3 Months">3 Months</option>
              </select>
            </div>
          </div>

          {/* Work Mode & Company Size */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-2">Preferred Work Mode</label>
              <div className="flex flex-wrap gap-2">
                {workModes.map((mode) => {
                  const isSelected = Array.isArray(data.work_mode)
                    ? data.work_mode.includes(mode)
                    : typeof data.work_mode === "string" && data.work_mode.includes(mode);
                  return (
                    <button
                      key={mode}
                      type="button"
                      onClick={() => handleToggleWorkMode(mode)}
                      className={`px-4 py-2 text-xs font-semibold rounded-lg border transition-all cursor-pointer min-h-[44px] ${
                        isSelected
                          ? "bg-primary text-white border-primary shadow-sm"
                          : "bg-white border-slate-200 text-slate-600 hover:border-slate-300"
                      }`}
                    >
                      {mode}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-2">Preferred Company Size</label>
              <select
                value={data.preferred_company_size || ""}
                onChange={(e) => onChange("preferred_company_size", e.target.value)}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700"
              >
                <option value="">Select Company Size</option>
                {companySizes.map((size) => (
                  <option key={size} value={size}>
                    {size}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Relocation & International Opportunities Toggles */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center justify-between p-4 bg-slate-50 border border-slate-200 rounded-xl">
              <div>
                <p className="text-xs font-bold text-slate-800">Open to Relocation</p>
                <p className="text-xs text-slate-500 font-medium mt-0.5">Willing to move for correct opportunities</p>
              </div>
              <button
                type="button"
                onClick={() => onChange("open_to_relocation", !data.open_to_relocation)}
                className={`relative w-12 h-6 rounded-full transition-colors flex-shrink-0 min-h-[44px] cursor-pointer ${
                  data.open_to_relocation ? "bg-primary" : "bg-slate-200"
                }`}
              >
                <span
                  className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${
                    data.open_to_relocation ? "right-0.5" : "left-0.5"
                  }`}
                ></span>
              </button>
            </div>

            <div className="flex items-center justify-between p-4 bg-slate-50 border border-slate-200 rounded-xl">
              <div>
                <p className="text-xs font-bold text-slate-800">International Opportunities</p>
                <p className="text-xs text-slate-500 font-medium mt-0.5">Open to jobs based outside home country</p>
              </div>
              <button
                type="button"
                onClick={() => onChange("open_to_international", !data.open_to_international)}
                className={`relative w-12 h-6 rounded-full transition-colors flex-shrink-0 min-h-[44px] cursor-pointer ${
                  data.open_to_international ? "bg-primary" : "bg-slate-200"
                }`}
              >
                <span
                  className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${
                    data.open_to_international ? "right-0.5" : "left-0.5"
                  }`}
                ></span>
              </button>
            </div>
          </div>

          {/* Preferred Locations */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-2">Preferred Cities / Locations</label>
            <div className="flex flex-wrap gap-2 mb-3">
              {locations.map((loc) => (
                <span
                  key={loc}
                  className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 text-slate-700 pl-3 pr-2 py-1 rounded-lg text-xs font-semibold"
                >
                  <span className="material-symbols-outlined text-sm text-indigo-500">location_on</span>
                  {loc}
                  <button
                    type="button"
                    onClick={() => handleRemoveLocation(loc)}
                    className="hover:text-red-500 ml-1 text-slate-400 flex items-center justify-center cursor-pointer min-h-[32px] min-w-[32px]"
                  >
                    <span className="material-symbols-outlined text-xs">close</span>
                  </button>
                </span>
              ))}
            </div>
            <div className="relative">
              <input
                type="text"
                value={locInput}
                onChange={(e) => setLocInput(e.target.value)}
                onKeyDown={handleAddLocation}
                placeholder="Type preferred city and press Enter..."
                className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
