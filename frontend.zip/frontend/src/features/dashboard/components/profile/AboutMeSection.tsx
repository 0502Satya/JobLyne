"use client";

import React, { useState } from "react";

interface AboutMeSectionProps {
  data: {
    bio?: string;
  };
  onChange: (field: "bio", value: string) => void;
  isExpanded?: boolean;
  onToggleExpand?: () => void;
}

export default function AboutMeSection({ data, onChange, isExpanded = true, onToggleExpand }: AboutMeSectionProps) {
  const [isPreview, setIsPreview] = useState(false);
  const characterLimit = 1000;
  const bioLength = data.bio?.length || 0;

  // Pre-configured AI Career summary suggestions
  const aiSuggestions = [
    "Experienced software engineer specialized in building robust and scalable cloud-native web applications with React, TypeScript, and Node.js. Passionate about automated testing and system design.",
    "Detail-oriented UX/UI Designer with 5+ years of experience designing mobile first products and digital interfaces. Skilled in wireframing, interactive prototyping, and user-centric design methodologies.",
    "Driven and proactive Computer Science graduate seeking an entry level position to leverage technical skills in Python, algorithms, and SQL database management.",
  ];

  const handleToolbarClick = (syntax: string) => {
    const text = data.bio || "";
    let inserted = "";
    if (syntax === "bold") inserted = `**text**`;
    else if (syntax === "italic") inserted = `*text*`;
    else if (syntax === "list") inserted = `\n- Item 1\n- Item 2`;
    else if (syntax === "link") inserted = `[link title](https://url.com)`;

    onChange("bio", text + inserted);
  };

  const handleApplySuggestion = (suggestion: string) => {
    onChange("bio", suggestion);
  };

  const isComplete = !!data.bio;

  return (
    <section className="bg-white rounded-2xl border border-slate-200/80 shadow-sm transition-all duration-300 overflow-hidden" id="about">
      {/* Collapsible Header */}
      <button
        type="button"
        onClick={onToggleExpand}
        className="w-full flex items-center justify-between p-5 text-left hover:bg-slate-50/50 transition-colors focus:outline-none focus:ring-2 focus:ring-primary/20 cursor-pointer"
        aria-expanded={isExpanded}
      >
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-primary/5 flex items-center justify-center text-primary shrink-0">
            <span className="material-symbols-outlined text-xl">description</span>
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-800 leading-tight">About / Professional Summary</h3>
            <p className="text-xs text-slate-500 mt-0.5">Introduce yourself to recruiters</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {isComplete ? (
            <span className="px-2.5 py-0.5 bg-emerald-50 text-emerald-600 text-xs font-semibold rounded-full flex items-center gap-1 border border-emerald-100/50">
              <span className="material-symbols-outlined text-sm font-bold">check_circle</span>
              Complete
            </span>
          ) : (
            <span className="px-2.5 py-0.5 bg-slate-50 text-slate-650 text-xs font-semibold rounded-full border border-slate-200">
              Optional
            </span>
          )}
          <span className={`material-symbols-outlined text-slate-400 transition-transform ${isExpanded ? "rotate-180" : ""}`}>
            expand_more
          </span>
        </div>
      </button>

      {/* Expanded Content */}
      <div
        className={`transition-all duration-500 ease-in-out overflow-hidden ${
          isExpanded ? "max-h-[1000px] opacity-100 border-t border-slate-100" : "max-h-0 opacity-0 pointer-events-none"
        }`}
      >
        <div className="p-5 sm:p-6 bg-white space-y-6">
          <div className="flex justify-end">
            {/* Toggle Mode */}
            <div className="flex bg-slate-100 rounded-xl p-1">
              <button
                type="button"
                onClick={() => setIsPreview(false)}
                className={`px-4 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer min-h-[44px] flex items-center justify-center ${
                  !isPreview ? "bg-white text-slate-800 shadow-sm" : "text-slate-500 hover:text-slate-800"
                }`}
              >
                Edit
              </button>
              <button
                type="button"
                onClick={() => setIsPreview(true)}
                className={`px-4 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer min-h-[44px] flex items-center justify-center ${
                  isPreview ? "bg-white text-slate-800 shadow-sm" : "text-slate-500 hover:text-slate-800"
                }`}
              >
                Preview
              </button>
            </div>
          </div>

          <div className="space-y-4">
            {!isPreview ? (
              <div className="space-y-3">
                {/* Formatting Toolbar */}
                <div className="flex flex-wrap items-center gap-1.5 bg-slate-50 p-2 rounded-lg border border-slate-200">
                  <button
                    type="button"
                    onClick={() => handleToolbarClick("bold")}
                    className="w-8 h-8 rounded hover:bg-slate-200/50 flex items-center justify-center text-slate-600 font-bold cursor-pointer"
                    title="Bold"
                  >
                    B
                  </button>
                  <button
                    type="button"
                    onClick={() => handleToolbarClick("italic")}
                    className="w-8 h-8 rounded hover:bg-slate-200/50 flex items-center justify-center text-slate-600 italic cursor-pointer"
                    title="Italic"
                  >
                    I
                  </button>
                  <button
                    type="button"
                    onClick={() => handleToolbarClick("list")}
                    className="w-8 h-8 rounded hover:bg-slate-200/50 flex items-center justify-center text-slate-600 cursor-pointer"
                    title="Bullet List"
                  >
                    <span className="material-symbols-outlined text-base">format_list_bulleted</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleToolbarClick("link")}
                    className="w-8 h-8 rounded hover:bg-slate-200/50 flex items-center justify-center text-slate-600 cursor-pointer"
                    title="Link"
                  >
                    <span className="material-symbols-outlined text-base">link</span>
                  </button>
                </div>

                {/* Input Area */}
                <div className="relative">
                  <textarea
                    value={data.bio || ""}
                    onChange={(e) => onChange("bio", e.target.value.slice(0, characterLimit))}
                    rows={6}
                    placeholder="I am a passionate software engineer..."
                    className="w-full bg-slate-50/50 border border-slate-200 rounded-xl py-3 px-4 text-sm font-medium text-slate-700 placeholder:text-slate-400 focus:border-primary focus:ring-1 focus:ring-primary/20 transition-all leading-relaxed resize-none"
                  />
                  <span className={`absolute bottom-3 right-4 text-xs font-semibold ${
                    bioLength >= characterLimit ? "text-red-500" : "text-slate-500"
                  }`}>
                    {bioLength} / {characterLimit} Chars
                  </span>
                </div>

                {/* AI Generator Suggestions Drawer */}
                <div className="bg-slate-50/50 border border-slate-200 rounded-xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-500 flex items-center gap-1.5">
                      <span className="material-symbols-outlined text-sm text-primary font-bold">star</span>
                      AI summary suggestions
                    </span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {aiSuggestions.map((s, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => handleApplySuggestion(s)}
                        className="p-3.5 text-left bg-white hover:bg-slate-50 border border-slate-200 rounded-lg transition-all text-xs font-medium text-slate-655 leading-normal shadow-sm flex flex-col justify-between cursor-pointer min-h-[100px]"
                      >
                        <span className="line-clamp-3 mb-2">{s}</span>
                        <span className="text-xs font-semibold text-primary flex items-center gap-0.5">
                          Apply <span className="material-symbols-outlined text-xs">arrow_forward</span>
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              /* Preview Area */
              <div className="bg-slate-50/50 border border-slate-200 rounded-xl p-4 min-h-[150px] leading-relaxed text-slate-700 text-sm font-medium whitespace-pre-line">
                {data.bio || <span className="text-slate-400 italic">No summary written yet. Click edit to write one.</span>}
              </div>
            )}

            {/* Tone Recommendation tips */}
            <div className="flex items-start gap-3 p-4 bg-slate-50 border border-slate-200 rounded-xl">
              <span className="material-symbols-outlined text-primary font-bold mt-0.5">tips_and_updates</span>
              <div className="text-xs text-slate-600 leading-normal">
                <span className="font-bold block mb-0.5">Tone recommendation</span>
                Keep it active and outcome oriented. Highlight your top 3 stack expertise and major production scale projects.
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
