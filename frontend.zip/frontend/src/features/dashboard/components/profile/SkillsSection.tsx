"use client";

import React, { useState } from "react";

interface SkillsSectionProps {
  data: string[];
  onChange: (skills: string[]) => void;
  isExpanded?: boolean;
  onToggleExpand?: () => void;
}

const TRENDING_RECOMMENDATIONS = ["Next.js", "Docker", "Kubernetes", "Tailwind CSS", "Framer Motion", "System Design"];

export default function SkillsSection({ data = [], onChange, isExpanded = false, onToggleExpand }: SkillsSectionProps) {
  const [skills, setSkills] = useState<string[]>(data);
  const [inputValue, setInputValue] = useState("");
  const [proficiencies, setProficiencies] = useState<Record<string, string>>({});

  React.useEffect(() => {
    setSkills(data);
  }, [data]);

  const addSkill = (skill: string) => {
    const trimmed = skill.trim();
    if (trimmed && !skills.includes(trimmed)) {
      const updated = [...skills, trimmed];
      setSkills(updated);
      onChange(updated);
      // Default proficiency
      setProficiencies((prev) => ({ ...prev, [trimmed]: "Intermediate" }));
    }
    setInputValue("");
  };

  const removeSkill = (skill: string) => {
    const updated = skills.filter((s) => s !== skill);
    setSkills(updated);
    onChange(updated);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      addSkill(inputValue);
    }
  };

  const changeProficiency = (skill: string, level: string) => {
    setProficiencies((prev) => ({ ...prev, [skill]: level }));
  };

  const moveSkill = (index: number, direction: "left" | "right") => {
    const updated = [...skills];
    const target = direction === "left" ? index - 1 : index + 1;
    if (target >= 0 && target < updated.length) {
      const temp = updated[index];
      updated[index] = updated[target];
      updated[target] = temp;
      setSkills(updated);
      onChange(updated);
    }
  };

  const isComplete = skills.length >= 3;

  return (
    <section className="bg-white rounded-2xl border border-slate-200/80 shadow-sm transition-all duration-300 overflow-hidden" id="skills">
      {/* Collapsible Header */}
      <button
        type="button"
        onClick={onToggleExpand}
        className="w-full flex items-center justify-between p-5 text-left hover:bg-slate-50/50 transition-colors focus:outline-none focus:ring-2 focus:ring-primary/20 cursor-pointer"
        aria-expanded={isExpanded}
      >
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-primary/5 flex items-center justify-center text-primary shrink-0">
            <span className="material-symbols-outlined text-xl">bolt</span>
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-800 leading-tight">Skills & Expertise</h3>
            <p className="text-xs text-slate-500 mt-0.5">Showcase your technical & soft skills</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {isComplete ? (
            <span className="px-2.5 py-0.5 bg-emerald-50 text-emerald-600 text-xs font-semibold rounded-full flex items-center gap-1 border border-emerald-100/50">
              <span className="material-symbols-outlined text-sm font-bold">check_circle</span>
              {skills.length} Added
            </span>
          ) : (
            <span className="px-2.5 py-0.5 bg-amber-50 text-amber-700 text-xs font-semibold rounded-full border border-amber-100/50 animate-pulse">
              Required
            </span>
          )}
          <span className={`material-symbols-outlined text-slate-400 transition-transform ${isExpanded ? "rotate-180" : ""}`}>
            expand_more
          </span>
        </div>
      </button>

      {/* Expanded Content */}
      <div
        className={`transition-all duration-500 ease-in-out overflow-hidden ${
          isExpanded ? "max-h-[1000px] opacity-100 border-t border-slate-100" : "max-h-0 opacity-0 pointer-events-none"
        }`}
      >
        <div className="p-5 sm:p-6 bg-white space-y-6">
          {/* Search & Autocomplete */}
          <div className="relative">
            <span className="material-symbols-outlined absolute left-3.5 top-2.5 text-slate-400">search</span>
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Search & add skills (e.g. Next.js, Product Design)..."
              className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
            />
          </div>

          {/* Selected Skills Chips */}
          <div>
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2.5">Your Skills</h4>
            {skills.length === 0 ? (
              <p className="text-xs text-slate-500 italic">No skills added yet. Add some to build recruiter discoverability.</p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {skills.map((skill, idx) => {
                  const currentLevel = proficiencies[skill] || "Intermediate";
                  return (
                    <div
                      key={skill}
                      className="group flex flex-wrap items-center bg-slate-50 border border-slate-200 text-slate-700 pl-3 pr-1.5 py-1.5 rounded-lg text-xs font-semibold shadow-sm gap-2"
                    >
                      <span>{skill}</span>
                      
                      {/* Proficiency drop */}
                      <select
                        value={currentLevel}
                        onChange={(e) => changeProficiency(skill, e.target.value)}
                        className="bg-white border border-slate-200 rounded text-xs font-semibold uppercase text-primary px-1.5 py-0.5 outline-none cursor-pointer"
                      >
                        <option value="Beginner">Beginner</option>
                        <option value="Intermediate">Intermediate</option>
                        <option value="Advanced">Advanced</option>
                        <option value="Expert">Expert</option>
                      </select>

                      {/* Sorting & Deleting */}
                      <div className="flex items-center gap-1 opacity-100 lg:opacity-0 lg:group-hover:opacity-100 transition-opacity ml-1">
                        <button
                          type="button"
                          disabled={idx === 0}
                          onClick={() => moveSkill(idx, "left")}
                          className="text-slate-450 hover:text-primary disabled:opacity-30 cursor-pointer min-w-[44px] min-h-[44px] flex items-center justify-center"
                        >
                          <span className="material-symbols-outlined text-xs">chevron_left</span>
                        </button>
                        <button
                          type="button"
                          disabled={idx === skills.length - 1}
                          onClick={() => moveSkill(idx, "right")}
                          className="text-slate-455 hover:text-primary disabled:opacity-30 cursor-pointer min-w-[44px] min-h-[44px] flex items-center justify-center"
                        >
                          <span className="material-symbols-outlined text-xs">chevron_right</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => removeSkill(skill)}
                          className="text-slate-400 hover:text-red-500 transition-colors cursor-pointer min-w-[44px] min-h-[44px] flex items-center justify-center"
                        >
                          <span className="material-symbols-outlined text-xs font-bold">close</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

            {/* Trending Recommendations */}
            <div className="pt-4 border-t border-slate-100">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2.5">Trending in your industry</h4>
              <div className="flex flex-wrap gap-2">
                {TRENDING_RECOMMENDATIONS.filter((s) => !skills.includes(s)).map((skill) => (
                  <button
                    key={skill}
                    type="button"
                    onClick={() => addSkill(skill)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-semibold text-slate-600 hover:border-primary hover:text-primary hover:bg-slate-50 transition-all cursor-pointer min-h-[44px]"
                  >
                    <span className="material-symbols-outlined text-xs">add</span>
                    {skill}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
  );
}
