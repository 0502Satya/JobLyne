"use client";

import React from "react";
import { PrivacySettings } from "@/types/profile";

interface PrivacySettingsSectionProps {
  privacySettings: PrivacySettings;
  onChange: (settings: PrivacySettings) => void;
  isExpanded?: boolean;
  onToggleExpand?: () => void;
}

export default function PrivacySettingsSection({ privacySettings, onChange, isExpanded = false, onToggleExpand }: PrivacySettingsSectionProps) {
  const settings = privacySettings || {
    public_profile: true,
    visible_to_recruiters_only: false,
    hide_current_company: false,
    anonymous_applications: false,
  };

  const handleToggle = (key: keyof PrivacySettings) => {
    const updated: PrivacySettings = {
      ...settings,
      [key]: !settings[key],
    };
    onChange(updated);
  };

  const options: {
    key: keyof PrivacySettings;
    title: string;
    description: string;
    icon: string;
  }[] = [
    {
      key: "public_profile",
      title: "Public Profile",
      description: "Allow anyone on the internet to view your professional credentials.",
      icon: "public",
    },
    {
      key: "visible_to_recruiters_only",
      title: "Visible to Recruiters Only",
      description: "Hide your profile from search engines and non-recruiter user accounts.",
      icon: "admin_panel_settings",
    },
    {
      key: "hide_current_company",
      title: "Hide Current Company",
      description: "Prevent your current employer from seeing your job search profile.",
      icon: "domain_disabled",
    },
    {
      key: "anonymous_applications",
      title: "Anonymous Applications",
      description: "Submit applications showing details without name/photo until selected.",
      icon: "visibility_off",
    },
  ];

  const isComplete = !!privacySettings;

  return (
    <section className="bg-white rounded-2xl border border-slate-200/80 shadow-sm transition-all duration-300 overflow-hidden" id="privacy">
      {/* Collapsible Header */}
      <button
        type="button"
        onClick={onToggleExpand}
        className="w-full flex items-center justify-between p-5 text-left hover:bg-slate-50/50 transition-colors focus:outline-none focus:ring-2 focus:ring-primary/20 cursor-pointer"
        aria-expanded={isExpanded}
      >
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-primary/5 flex items-center justify-center text-primary shrink-0">
            <span className="material-symbols-outlined text-xl">shield</span>
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-800 leading-tight">Recruiter Visibility & Privacy</h3>
            <p className="text-xs text-slate-500 mt-0.5">Manage your profile discoverability settings</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {isComplete ? (
            <span className="px-2.5 py-0.5 bg-emerald-50 text-emerald-600 text-xs font-semibold rounded-full flex items-center gap-1 border border-emerald-100/50">
              <span className="material-symbols-outlined text-sm font-bold">check_circle</span>
              Configured
            </span>
          ) : (
            <span className="px-2.5 py-0.5 bg-slate-50 text-slate-650 text-xs font-semibold rounded-full border border-slate-200">
              Optional
            </span>
          )}
          <span className={`material-symbols-outlined text-slate-400 transition-transform ${isExpanded ? "rotate-180" : ""}`}>
            expand_more
          </span>
        </div>
      </button>

      {/* Expanded Content */}
      <div className={`transition-all duration-500 ease-in-out overflow-hidden ${isExpanded ? "max-h-[1000px] opacity-100 border-t border-slate-100" : "max-h-0 opacity-0 pointer-events-none"}`}>
        <div className="p-5 sm:p-6 bg-white space-y-5">
          <div className="space-y-4">
            {options.map((opt) => {
              const isActive = !!settings[opt.key];
              return (
                <div
                  key={opt.key}
                  className="flex items-center justify-between p-4 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-slate-50 transition-all gap-4"
                >
                  <div className="flex items-start gap-3.5">
                    <div className="w-9 h-9 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-500 shrink-0 shadow-sm">
                      <span className="material-symbols-outlined text-lg">{opt.icon}</span>
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-800 tracking-tight mb-0.5">{opt.title}</h4>
                      <p className="text-xs text-slate-500 leading-normal font-medium">{opt.description}</p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleToggle(opt.key)}
                    className={`relative w-12 h-6 rounded-full transition-colors flex-shrink-0 min-h-[44px] cursor-pointer ${
                      isActive ? "bg-primary" : "bg-slate-350"
                    }`}
                  >
                    <span
                      className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${
                        isActive ? "right-0.5" : "left-0.5"
                      }`}
                    ></span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
