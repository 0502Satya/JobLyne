"use client";

import React, { useState, useRef } from "react";
import { Profile, Language } from "@/types/profile";

interface PersonalInfoSectionProps {
  profile: Profile | null;
  onChange: <K extends keyof Profile>(field: K, value: Profile[K]) => void;
  isExpanded?: boolean;
  onToggleExpand?: () => void;
}

export default function PersonalInfoSection({ profile, onChange, isExpanded = true, onToggleExpand }: PersonalInfoSectionProps) {
  // Crop Tool Modal state
  const [showCropModal, setShowCropModal] = useState(false);
  const [cropZoom, setCropZoom] = useState(1);
  const [cropOffset, setCropOffset] = useState({ x: 0, y: 0 });
  const [tempPhotoUrl, setTempPhotoUrl] = useState<string | null>(null);

  // Resume state
  const [resumeFile, setResumeFile] = useState<string | null>(profile?.resume_file_url ? "Resume uploaded" : null);
  const [parsingProgress, setParsingProgress] = useState(0);
  const [isParsing, setIsParsing] = useState(false);

  // Languages known
  const [langInput, setLangInput] = useState("");
  const [langProficiency, setLangProficiency] = useState("Intermediate");

  const fileInputRef = useRef<HTMLInputElement>(null);
  const resumeInputRef = useRef<HTMLInputElement>(null);

  // Photo Crop/Zoom Handler
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const url = URL.createObjectURL(e.target.files[0]);
      setTempPhotoUrl(url);
      setShowCropModal(true);
    }
  };

  const handleApplyCrop = () => {
    if (tempPhotoUrl) {
      onChange("profile_photo_url", tempPhotoUrl);
      setShowCropModal(false);
    }
  };

  // Resume drag & drop
  const handleResumeDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processResume(e.dataTransfer.files[0]);
    }
  };

  const handleResumeFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processResume(e.target.files[0]);
    }
  };

  const processResume = (file: File) => {
    setIsParsing(true);
    setParsingProgress(10);
    const interval = setInterval(() => {
      setParsingProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsParsing(false);
          setResumeFile(file.name);
          onChange("resume_file_url", URL.createObjectURL(file));
          // Pre-populate professional headline from file name as helper
          if (!profile?.headline) {
            onChange("headline", `${file.name.replace(/\.[^/.]+$/, "")} Expert`);
          }
          return 100;
        }
        return prev + 30;
      });
    }, 400);
  };

  // Languages handlers
  const handleAddLanguage = () => {
    const lang = langInput.trim();
    if (lang) {
      const current = profile?.languages || [];
      const updated = [...current, { name: lang, proficiency: langProficiency }];
      onChange("languages", updated);
      setLangInput("");
    }
  };

  const handleRemoveLanguage = (idx: number) => {
    const current = profile?.languages || [];
    const updated = current.filter((_, i) => i !== idx);
    onChange("languages", updated);
  };

  const isComplete = !!(profile?.first_name && profile?.last_name && profile?.email && profile?.phone);

  return (
    <section className="bg-white rounded-2xl border border-slate-200/80 shadow-sm transition-all duration-300 overflow-hidden" id="personal">
      {/* Collapsible Header */}
      <button
        type="button"
        onClick={onToggleExpand}
        className="w-full flex items-center justify-between p-5 text-left hover:bg-slate-50/50 transition-colors focus:outline-none focus:ring-2 focus:ring-primary/20 cursor-pointer"
        aria-expanded={isExpanded}
      >
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-primary/5 flex items-center justify-center text-primary shrink-0">
            <span className="material-symbols-outlined text-xl">person</span>
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-800 leading-tight">Personal Details & Resume</h3>
            <p className="text-xs text-slate-500 mt-0.5">Create your professional identity</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {isComplete ? (
            <span className="px-2.5 py-0.5 bg-emerald-50 text-emerald-600 text-xs font-semibold rounded-full flex items-center gap-1 border border-emerald-100/50">
              <span className="material-symbols-outlined text-sm font-bold">check_circle</span>
              Complete
            </span>
          ) : (
            <span className="px-2.5 py-0.5 bg-amber-50 text-amber-700 text-xs font-semibold rounded-full border border-amber-100/50 animate-pulse">
              Required
            </span>
          )}
          <span className={`material-symbols-outlined text-slate-400 transition-transform ${isExpanded ? "rotate-180" : ""}`}>
            expand_more
          </span>
        </div>
      </button>

      {/* Expanded Content */}
      <div
        className={`transition-all duration-500 ease-in-out overflow-hidden ${
          isExpanded ? "max-h-[2500px] opacity-100 border-t border-slate-100" : "max-h-0 opacity-0 pointer-events-none"
        }`}
      >
        <div className="p-5 sm:p-6 bg-white space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-[180px_1fr] gap-8">
            {/* Left Column: Photo & Resume Drop */}
            <div className="flex flex-col items-center gap-6">
              {/* Profile Photo */}
              <div className="relative group w-32 h-32 rounded-full overflow-hidden border-2 border-slate-100 shadow-sm bg-slate-50 flex items-center justify-center">
                {profile?.profile_photo_url ? (
                  <img
                    src={profile.profile_photo_url}
                    alt="Profile"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <span className="material-symbols-outlined text-3xl text-slate-350">add_a_photo</span>
                )}
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute inset-0 bg-slate-900/60 text-white opacity-100 lg:opacity-0 lg:group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-xs font-bold cursor-pointer"
                >
                  <span className="material-symbols-outlined text-base mb-1">edit</span>
                  Upload
                </button>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handlePhotoUpload}
                  accept="image/*"
                  className="hidden"
                />
              </div>

              {/* Resume Upload Box */}
              <div
                onDragOver={(e) => e.preventDefault()}
                onDrop={handleResumeDrop}
                className="w-full border border-dashed border-slate-300 hover:border-primary/50 transition-all rounded-xl p-4 text-center cursor-pointer bg-slate-50/50 hover:bg-slate-50"
                onClick={() => resumeInputRef.current?.click()}
              >
                <span className="material-symbols-outlined text-xl text-slate-400 mb-1 block">upload_file</span>
                <span className="text-xs font-semibold text-slate-700 block mb-0.5">Drag Resume Here</span>
                <span className="text-xs text-slate-500 block">PDF, DOC or DOCX (Max 5MB)</span>
                <input
                  type="file"
                  ref={resumeInputRef}
                  onChange={handleResumeFileSelect}
                  accept=".pdf,.doc,.docx"
                  className="hidden"
                />
                {isParsing && (
                  <div className="mt-3 space-y-1">
                    <div className="flex justify-between text-xs font-semibold text-primary uppercase tracking-wide">
                      <span>Parsing Resume...</span>
                      <span>{parsingProgress}%</span>
                    </div>
                    <div className="w-full bg-slate-200 h-1 rounded-full overflow-hidden">
                      <div className="bg-primary h-full transition-all duration-350" style={{ width: `${parsingProgress}%` }}></div>
                    </div>
                  </div>
                )}
                {resumeFile && !isParsing && (
                  <div className="mt-3 flex items-center justify-center gap-1 text-xs font-semibold text-emerald-600 bg-emerald-50 py-1.5 px-2 rounded-lg border border-emerald-100 truncate">
                    <span className="material-symbols-outlined text-xs">check_circle</span>
                    <span className="truncate">{resumeFile}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Right Column: Information form fields */}
            <div className="space-y-5 min-w-0">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">First Name</label>
                  <input
                    type="text"
                    value={profile?.first_name || ""}
                    onChange={(e) => onChange("first_name", e.target.value)}
                    placeholder="John"
                    className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">Middle Name</label>
                  <input
                    type="text"
                    value={profile?.middle_name || ""}
                    onChange={(e) => onChange("middle_name", e.target.value)}
                    placeholder="David"
                    className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">Last Name</label>
                  <input
                    type="text"
                    value={profile?.last_name || ""}
                    onChange={(e) => onChange("last_name", e.target.value)}
                    placeholder="Doe"
                    className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Professional Headline</label>
                <input
                  type="text"
                  value={profile?.headline || ""}
                  onChange={(e) => onChange("headline", e.target.value)}
                  placeholder="e.g. Senior Frontend Architect | React & TypeScript specialist"
                  className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">Email Address</label>
                  <div className="relative">
                    <input
                      type="email"
                      value={profile?.email || ""}
                      onChange={(e) => onChange("email", e.target.value)}
                      placeholder="john.doe@example.com"
                      className="w-full pl-3.5 pr-20 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                    />
                    <span className="absolute right-2 top-1.5 px-2 py-0.5 bg-emerald-50 text-emerald-600 text-xs font-semibold rounded border border-emerald-100 flex items-center gap-0.5">
                      <span className="material-symbols-outlined text-xs font-bold">check_circle</span> Verified
                    </span>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">Phone Number</label>
                  <div className="relative">
                    <input
                      type="text"
                      value={profile?.phone || ""}
                      onChange={(e) => onChange("phone", e.target.value)}
                      placeholder="+1 (555) 019-2834"
                      className="w-full pl-3.5 pr-20 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                    />
                    <span className="absolute right-2 top-1.5 px-2 py-0.5 bg-emerald-50 text-emerald-600 text-xs font-semibold rounded border border-emerald-100 flex items-center gap-0.5">
                      <span className="material-symbols-outlined text-xs font-bold">check_circle</span> Verified
                    </span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">Date of Birth</label>
                  <input
                    type="date"
                    value={profile?.date_of_birth || ""}
                    onChange={(e) => onChange("date_of_birth", e.target.value)}
                    className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">Gender</label>
                  <select
                    value={profile?.gender || ""}
                    onChange={(e) => onChange("gender", e.target.value)}
                    className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700"
                  >
                    <option value="">Select Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                    <option value="Prefer not to say">Prefer not to say</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">Nationality</label>
                  <input
                    type="text"
                    value={profile?.nationality || ""}
                    onChange={(e) => onChange("nationality", e.target.value)}
                    placeholder="Canadian"
                    className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">Current Location</label>
                  <input
                    type="text"
                    value={profile?.location || ""}
                    onChange={(e) => onChange("location", e.target.value)}
                    placeholder="Vancouver, BC"
                    className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">Hometown</label>
                  <input
                    type="text"
                    value={profile?.hometown || ""}
                    onChange={(e) => onChange("hometown", e.target.value)}
                    placeholder="Toronto"
                    className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">Pincode</label>
                  <input
                    type="text"
                    value={profile?.pincode || ""}
                    onChange={(e) => onChange("pincode", e.target.value)}
                    placeholder="V6B 1A1"
                    className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                  />
                </div>
              </div>

              {/* Portfolio & Social Link Fields */}
              <div className="space-y-4 pt-4 border-t border-slate-100">
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Websites & Portfolios</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Portfolio Website</label>
                    <input
                      type="text"
                      value={profile?.social_links?.portfolio || ""}
                      onChange={(e) => {
                        const links = { ...(profile?.social_links || {}), portfolio: e.target.value };
                        onChange("social_links", links);
                      }}
                      placeholder="https://johndoe.dev"
                      className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">LinkedIn Profile</label>
                    <input
                      type="text"
                      value={profile?.social_links?.linkedin || ""}
                      onChange={(e) => {
                        const links = { ...(profile?.social_links || {}), linkedin: e.target.value };
                        onChange("social_links", links);
                      }}
                      placeholder="https://linkedin.com/in/johndoe"
                      className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">GitHub Profile</label>
                    <input
                      type="text"
                      value={profile?.social_links?.github || ""}
                      onChange={(e) => {
                        const links = { ...(profile?.social_links || {}), github: e.target.value };
                        onChange("social_links", links);
                      }}
                      placeholder="https://github.com/johndoe"
                      className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                    />
                  </div>
                </div>
              </div>

              {/* Languages Section */}
              <div className="space-y-4 pt-4 border-t border-slate-100">
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Languages Known</h4>
                <div className="flex flex-wrap gap-2 mb-2">
                  {profile?.languages?.map((lang, i) => (
                    <span
                      key={i}
                      className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 text-slate-700 pl-3 pr-2 py-1 rounded-lg text-xs font-semibold"
                    >
                      {lang.name}
                      <span className="px-1.5 py-0.5 bg-primary/5 text-primary text-xs font-semibold rounded">
                        {lang.proficiency}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleRemoveLanguage(i)}
                        className="hover:text-red-500 ml-1 text-slate-400 flex items-center justify-center cursor-pointer min-h-[44px] min-w-[44px]"
                      >
                        <span className="material-symbols-outlined text-xs">close</span>
                      </button>
                    </span>
                  ))}
                </div>

                <div className="flex flex-col sm:flex-row gap-3">
                  <input
                    type="text"
                    value={langInput}
                    onChange={(e) => setLangInput(e.target.value)}
                    placeholder="Add Language (e.g. Spanish)"
                    className="flex-1 px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                  />
                  <select
                    value={langProficiency}
                    onChange={(e) => setLangProficiency(e.target.value)}
                    className="px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700"
                  >
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced">Advanced</option>
                    <option value="Expert">Expert</option>
                  </select>
                  <button
                    type="button"
                    onClick={handleAddLanguage}
                    className="px-4 py-2 bg-slate-50 text-slate-700 text-xs font-bold rounded-lg hover:bg-slate-100 border border-slate-200 flex items-center justify-center gap-1 min-h-[44px] cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-sm">add</span>
                    Add Language
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Image Cropper Modal */}
      {showCropModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full space-y-5 shadow-lg border border-slate-200">
            <div>
              <h4 className="text-base font-bold text-slate-800 tracking-tight">Adjust Profile Picture</h4>
              <p className="text-xs text-slate-500 mt-1">Position and zoom your photo to look your best.</p>
            </div>

            {/* Cropper viewport mock */}
            <div className="w-full aspect-square rounded-xl overflow-hidden bg-slate-100 border border-slate-200 flex items-center justify-center relative">
              <div className="absolute inset-4 rounded-full border border-white/80 border-dashed z-10 pointer-events-none shadow-[0_0_0_9999px_rgba(0,0,0,0.3)]"></div>
              {tempPhotoUrl && (
                <img
                  src={tempPhotoUrl}
                  alt="Crop preview"
                  className="max-w-none transition-transform"
                  style={{
                    transform: `scale(${cropZoom}) translate(${cropOffset.x}px, ${cropOffset.y}px)`,
                    width: "100%",
                    height: "100%",
                    objectFit: "contain",
                  }}
                />
              )}
            </div>

            {/* Zoom Slider */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold text-slate-500 uppercase">
                <span>Zoom</span>
                <span>{cropZoom.toFixed(1)}x</span>
              </div>
              <input
                type="range"
                min="1"
                max="3"
                step="0.1"
                value={cropZoom}
                onChange={(e) => setCropZoom(parseFloat(e.target.value))}
                className="w-full accent-primary"
              />
            </div>

            {/* Actions */}
            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowCropModal(false)}
                className="flex-1 py-2.5 text-slate-600 hover:text-slate-800 bg-slate-50 hover:bg-slate-100 font-bold text-xs rounded-lg transition-all min-h-[44px] border border-slate-200 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleApplyCrop}
                className="flex-1 py-2.5 bg-primary text-white font-bold text-xs rounded-lg hover:bg-primary/95 transition-all min-h-[44px] shadow-sm cursor-pointer"
              >
                Apply Crop
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
