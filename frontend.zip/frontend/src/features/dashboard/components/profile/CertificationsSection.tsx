"use client";

import React from "react";
import { Certification } from "@/types/profile";

interface CertificationsSectionProps {
  certifications: Certification[];
  onChange: (certifications: Certification[]) => void;
  isExpanded?: boolean;
  onToggleExpand?: () => void;
}

export default function CertificationsSection({ certifications = [], onChange, isExpanded = false, onToggleExpand }: CertificationsSectionProps) {
  const addCertification = () => {
    const newCert: Certification = {
      id: Date.now().toString(),
      name: "",
      issuing_organization: "",
      issue_date: "",
      expiry_date: "",
      credential_id: "",
      credential_url: "",
    };
    onChange([...certifications, newCert]);
  };

  const removeCertification = (id?: string | number) => {
    if (!id) return;
    const updated = certifications.filter((c) => c.id !== id);
    onChange(updated);
  };

  const updateCertification = (id: string | number | undefined, field: keyof Certification, value: any) => {
    if (!id) return;
    const updated = certifications.map((c) => (c.id === id ? { ...c, [field]: value } : c));
    onChange(updated);
  };

  const isComplete = certifications.length > 0;

  return (
    <section className="bg-white rounded-2xl border border-slate-200/80 shadow-sm transition-all duration-300 overflow-hidden" id="certifications">
      {/* Collapsible Header */}
      <button
        type="button"
        onClick={onToggleExpand}
        className="w-full flex items-center justify-between p-5 text-left hover:bg-slate-50/50 transition-colors focus:outline-none focus:ring-2 focus:ring-primary/20 cursor-pointer"
        aria-expanded={isExpanded}
      >
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-primary/5 flex items-center justify-center text-primary shrink-0">
            <span className="material-symbols-outlined text-xl">workspace_premium</span>
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-800 leading-tight">Certifications & Courses</h3>
            <p className="text-xs text-slate-500 mt-0.5">Prove your specialized knowledge</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {isComplete ? (
            <span className="px-2.5 py-0.5 bg-emerald-50 text-emerald-600 text-xs font-semibold rounded-full flex items-center gap-1 border border-emerald-100/50">
              <span className="material-symbols-outlined text-sm font-bold">check_circle</span>
              {certifications.length} Added
            </span>
          ) : (
            <span className="px-2.5 py-0.5 bg-slate-50 text-slate-650 text-xs font-semibold rounded-full border border-slate-200">
              Optional
            </span>
          )}
          <span className={`material-symbols-outlined text-slate-400 transition-transform ${isExpanded ? "rotate-180" : ""}`}>
            expand_more
          </span>
        </div>
      </button>

      {/* Expanded Content */}
      <div
        className={`transition-all duration-500 ease-in-out overflow-hidden ${
          isExpanded ? "max-h-[2500px] opacity-100 border-t border-slate-100" : "max-h-0 opacity-0 pointer-events-none"
        }`}
      >
        <div className="p-5 sm:p-6 bg-white space-y-6">
          <div className="flex justify-end">
            <button
              onClick={addCertification}
              type="button"
              className="px-4 py-2 bg-primary/5 text-primary text-xs font-bold rounded-lg hover:bg-primary hover:text-white transition-all border border-primary/10 flex items-center justify-center gap-1.5 min-h-[44px] cursor-pointer"
            >
              <span className="material-symbols-outlined text-sm">add</span>
              Add Certification
            </button>
          </div>

          <div className="space-y-8">
            {certifications.length === 0 ? (
              <div className="text-center py-10 border border-dashed border-slate-205 rounded-xl bg-slate-50/50">
                <span className="material-symbols-outlined text-3xl text-slate-350 mb-2 block">workspace_premium</span>
                <span className="text-sm font-bold text-slate-700 block mb-0.5">No certifications added yet</span>
                <span className="text-xs text-slate-500 block mb-4">Prove your domain credentials by adding coursework certifications.</span>
                <button
                  type="button"
                  onClick={addCertification}
                  className="text-primary text-xs font-bold hover:underline cursor-pointer min-h-[44px] px-4"
                >
                  Add first certificate card
                </button>
              </div>
            ) : (
              certifications.map((cert) => (
                <div
                  key={cert.id}
                  className="relative bg-slate-50/30 hover:bg-slate-50/70 border border-slate-205 rounded-xl p-5 transition-all group"
                >
                  {/* Delete Action */}
                  <div className="absolute top-3 right-3 opacity-100 lg:opacity-0 lg:group-hover:opacity-100 transition-opacity">
                    <button
                      type="button"
                      onClick={() => removeCertification(cert.id)}
                      className="w-11 h-11 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-red-500 hover:text-red-700 hover:bg-red-50 cursor-pointer"
                    >
                      <span className="material-symbols-outlined text-base">delete</span>
                    </button>
                  </div>

                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1">Certification Name</label>
                        <input
                          type="text"
                          value={cert.name || ""}
                          onChange={(e) => updateCertification(cert.id, "name", e.target.value)}
                          placeholder="e.g. AWS Certified Solutions Architect"
                          className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1">Issuing Organization</label>
                        <input
                          type="text"
                          value={cert.issuing_organization || ""}
                          onChange={(e) => updateCertification(cert.id, "issuing_organization", e.target.value)}
                          placeholder="e.g. Amazon Web Services (AWS)"
                          className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1">Issue Date</label>
                        <input
                          type="date"
                          value={cert.issue_date || ""}
                          onChange={(e) => updateCertification(cert.id, "issue_date", e.target.value)}
                          className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1">Expiration Date</label>
                        <input
                          type="date"
                          value={cert.expiry_date || ""}
                          onChange={(e) => updateCertification(cert.id, "expiry_date", e.target.value)}
                          className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1">Credential ID</label>
                        <input
                          type="text"
                          value={cert.credential_id || ""}
                          onChange={(e) => updateCertification(cert.id, "credential_id", e.target.value)}
                          placeholder="e.g. AWS-ASA-1234"
                          className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1">Credential URL</label>
                        <input
                          type="text"
                          value={cert.credential_url || ""}
                          onChange={(e) => updateCertification(cert.id, "credential_url", e.target.value)}
                          placeholder="https://cred.ly/aws-cert"
                          className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
