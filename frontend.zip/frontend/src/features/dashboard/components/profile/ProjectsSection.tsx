"use client";

import React, { useState } from "react";
import { Project } from "@/types/profile";

interface ProjectsSectionProps {
  projects: Project[];
  onChange: (projects: Project[]) => void;
  isExpanded?: boolean;
  onToggleExpand?: () => void;
}

export default function ProjectsSection({ projects = [], onChange, isExpanded = false, onToggleExpand }: ProjectsSectionProps) {
  const [techInput, setTechInput] = useState<{ [key: string]: string }>({});

  const addProject = () => {
    const newProject: Project = {
      id: Date.now().toString(),
      title: "",
      description: "",
      tech_stack: [],
      project_url: "",
      github_url: "",
      team_size: 1,
      role: "",
      duration: "",
    };
    const updated = [...projects, newProject];
    onChange(updated);
  };

  const removeProject = (id?: string | number) => {
    if (!id) return;
    const updated = projects.filter((p) => p.id !== id);
    onChange(updated);
  };

  const updateProject = (id: string | number | undefined, field: keyof Project, value: any) => {
    if (!id) return;
    const updated = projects.map((p) => (p.id === id ? { ...p, [field]: value } : p));
    onChange(updated);
  };

  const handleAddTech = (projId: string | number | undefined, val: string) => {
    if (!projId || !val.trim()) return;
    const proj = projects.find((p) => p.id === projId);
    if (!proj) return;

    let currentTechs: string[] = [];
    if (Array.isArray(proj.tech_stack)) {
      currentTechs = proj.tech_stack;
    } else if (typeof proj.tech_stack === "string") {
      currentTechs = proj.tech_stack.split(",").map((t) => t.trim()).filter(Boolean);
    }

    if (!currentTechs.includes(val.trim())) {
      const updatedTechs = [...currentTechs, val.trim()];
      updateProject(projId, "tech_stack", updatedTechs);
    }
    setTechInput((prev) => ({ ...prev, [projId]: "" }));
  };

  const handleRemoveTech = (projId: string | number | undefined, techName: string) => {
    if (!projId) return;
    const proj = projects.find((p) => p.id === projId);
    if (!proj) return;

    let currentTechs: string[] = [];
    if (Array.isArray(proj.tech_stack)) {
      currentTechs = proj.tech_stack;
    }

    const updatedTechs = currentTechs.filter((t) => t !== techName);
    updateProject(projId, "tech_stack", updatedTechs);
  };

  const isComplete = projects.length > 0;

  return (
    <section className="bg-white rounded-2xl border border-slate-200/80 shadow-sm transition-all duration-300 overflow-hidden" id="projects">
      {/* Collapsible Header */}
      <button
        type="button"
        onClick={onToggleExpand}
        className="w-full flex items-center justify-between p-5 text-left hover:bg-slate-50/50 transition-colors focus:outline-none focus:ring-2 focus:ring-primary/20 cursor-pointer"
        aria-expanded={isExpanded}
      >
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-primary/5 flex items-center justify-center text-primary shrink-0">
            <span className="material-symbols-outlined text-xl">folder_open</span>
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-800 leading-tight">Key Projects</h3>
            <p className="text-xs text-slate-500 mt-0.5">Showcase your practical project builds</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {isComplete ? (
            <span className="px-2.5 py-0.5 bg-emerald-50 text-emerald-600 text-xs font-semibold rounded-full flex items-center gap-1 border border-emerald-100/50">
              <span className="material-symbols-outlined text-sm font-bold">check_circle</span>
              {projects.length} {projects.length === 1 ? "Project" : "Projects"}
            </span>
          ) : (
            <span className="px-2.5 py-0.5 bg-slate-50 text-slate-650 text-xs font-semibold rounded-full border border-slate-200">
              Optional
            </span>
          )}
          <span className={`material-symbols-outlined text-slate-400 transition-transform ${isExpanded ? "rotate-180" : ""}`}>
            expand_more
          </span>
        </div>
      </button>

      {/* Expanded Content */}
      <div
        className={`transition-all duration-500 ease-in-out overflow-hidden ${
          isExpanded ? "max-h-[2500px] opacity-100 border-t border-slate-100" : "max-h-0 opacity-0 pointer-events-none"
        }`}
      >
        <div className="p-5 sm:p-6 bg-white space-y-6">
          <div className="flex justify-end">
            <button
              onClick={addProject}
              type="button"
              className="px-4 py-2 bg-primary/5 text-primary text-xs font-bold rounded-lg hover:bg-primary hover:text-white transition-all border border-primary/10 flex items-center justify-center gap-1.5 min-h-[44px] cursor-pointer"
            >
              <span className="material-symbols-outlined text-sm">add</span>
              Add Project
            </button>
          </div>

          <div className="space-y-8">
            {projects.length === 0 ? (
              <div className="text-center py-10 border border-dashed border-slate-205 rounded-xl bg-slate-50/50">
                <span className="material-symbols-outlined text-3xl text-slate-350 mb-2 block">folder</span>
                <span className="text-sm font-bold text-slate-700 block mb-0.5">No projects added yet</span>
                <span className="text-xs text-slate-500 block mb-4">Adding key projects boosts profile discovery index.</span>
                <button
                  type="button"
                  onClick={addProject}
                  className="text-primary text-xs font-bold hover:underline cursor-pointer min-h-[44px] px-4"
                >
                  Add first project card
                </button>
              </div>
            ) : (
              projects.map((proj) => {
                const techs = Array.isArray(proj.tech_stack)
                  ? proj.tech_stack
                  : typeof proj.tech_stack === "string"
                  ? proj.tech_stack.split(",").map((t) => t.trim()).filter(Boolean)
                  : [];

                return (
                  <div
                    key={proj.id}
                    className="relative bg-slate-50/30 hover:bg-slate-50/70 border border-slate-200 rounded-xl p-5 transition-all group"
                  >
                    {/* Delete Action */}
                    <div className="absolute top-3 right-3 opacity-100 lg:opacity-0 lg:group-hover:opacity-100 transition-opacity">
                      <button
                        type="button"
                        onClick={() => removeProject(proj.id)}
                        className="w-11 h-11 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-red-500 hover:text-red-700 hover:bg-red-50 cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-base">delete</span>
                      </button>
                    </div>

                    <div className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">Project Title</label>
                          <input
                            type="text"
                            value={proj.title || ""}
                            onChange={(e) => updateProject(proj.id, "title", e.target.value)}
                            placeholder="e.g. E-Commerce Platform"
                            className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">Your Role</label>
                          <input
                            type="text"
                            value={proj.role || ""}
                            onChange={(e) => updateProject(proj.id, "role", e.target.value)}
                            placeholder="e.g. Lead Architect"
                            className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">Duration</label>
                          <input
                            type="text"
                            value={proj.duration || ""}
                            onChange={(e) => updateProject(proj.id, "duration", e.target.value)}
                            placeholder="e.g. 3 Months"
                            className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">Project URL</label>
                          <input
                            type="text"
                            value={proj.project_url || ""}
                            onChange={(e) => updateProject(proj.id, "project_url", e.target.value)}
                            placeholder="https://myproject.com"
                            className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">GitHub Repository Link</label>
                          <input
                            type="text"
                            value={proj.github_url || ""}
                            onChange={(e) => updateProject(proj.id, "github_url", e.target.value)}
                            placeholder="https://github.com/myrepo"
                            className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="block text-xs font-semibold text-slate-500">Project Description</label>
                        <textarea
                          value={proj.description || ""}
                          onChange={(e) => updateProject(proj.id, "description", e.target.value)}
                          rows={3}
                          placeholder="Describe the problem solved, tech stack highlights, and achievements..."
                          className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3.5 text-sm font-medium text-slate-700 focus:border-primary focus:ring-1 focus:ring-primary/20 outline-none leading-relaxed resize-none placeholder:text-slate-400"
                        />
                      </div>

                      {/* Tech Stack tags */}
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-2">Tech Stack Used</label>
                        <div className="flex flex-wrap gap-2 mb-2">
                          {techs.map((tech) => (
                            <span
                              key={tech}
                              className="flex items-center gap-1 bg-white border border-slate-200 text-slate-655 pl-2.5 pr-1 py-1 rounded-lg text-xs font-medium"
                            >
                              {tech}
                              <button
                                type="button"
                                onClick={() => handleRemoveTech(proj.id, tech)}
                                className="hover:text-red-500 ml-1 text-slate-400 flex items-center justify-center cursor-pointer min-h-[44px] min-w-[44px]"
                              >
                                <span className="material-symbols-outlined text-xs">close</span>
                              </button>
                            </span>
                          ))}
                        </div>
                        <input
                          type="text"
                          value={techInput[proj.id as string] || ""}
                          onChange={(e) => setTechInput((prev) => ({ ...prev, [proj.id as string]: e.target.value }))}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              e.preventDefault();
                              handleAddTech(proj.id, techInput[proj.id as string]);
                            }
                          }}
                          placeholder="Type a technology (e.g. Next.js) and press Enter..."
                          className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-xs outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                        />
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
