"use client";

import React, { useState } from "react";
import { WorkExperience as Experience } from "@/types/profile";

interface WorkExperienceSectionProps {
  data: Experience[];
  onChange: (data: Experience[]) => void;
  isExpanded?: boolean;
  onToggleExpand?: () => void;
}

const employmentTypes = ["Full-time", "Part-time", "Contract", "Freelance", "Internship"];

export default function WorkExperienceSection({ data = [], onChange, isExpanded = false, onToggleExpand }: WorkExperienceSectionProps) {
  const [experience, setExperience] = useState<Experience[]>(data);
  const [techInput, setTechInput] = useState<{ [key: string]: string }>({});

  React.useEffect(() => {
    setExperience(data);
  }, [data]);

  const addEntry = () => {
    const newEntry: Experience = {
      id: Date.now().toString(),
      title: "",
      company: "",
      start_date: "",
      end_date: "",
      description: "",
      current: false,
      employment_type: "Full-time",
      location: "",
      technologies: [],
      achievements: "",
    };
    const updated = [...experience, newEntry];
    setExperience(updated);
    onChange(updated);
  };

  const removeEntry = (id?: string | number) => {
    if (!id) return;
    const updated = experience.filter((e) => e.id !== id);
    setExperience(updated);
    onChange(updated);
  };

  const updateEntry = (id: string | number | undefined, field: keyof Experience, value: any) => {
    if (!id) return;
    const updated = experience.map((e) => (e.id === id ? { ...e, [field]: value } : e));
    setExperience(updated);
    onChange(updated);
  };

  // Reordering handlers
  const moveEntry = (index: number, direction: "up" | "down") => {
    const updated = [...experience];
    const targetIndex = direction === "up" ? index - 1 : index + 1;
    if (targetIndex >= 0 && targetIndex < updated.length) {
      const temp = updated[index];
      updated[index] = updated[targetIndex];
      updated[targetIndex] = temp;
      setExperience(updated);
      onChange(updated);
    }
  };

  // Technologies Tag Handlers
  const handleAddTech = (expId: string | number | undefined, value: string) => {
    if (!expId || !value.trim()) return;
    const exp = experience.find((e) => e.id === expId);
    if (!exp) return;

    let currentTechs: string[] = [];
    if (Array.isArray(exp.technologies)) {
      currentTechs = exp.technologies;
    } else if (typeof exp.technologies === "string") {
      currentTechs = exp.technologies.split(",").map((t) => t.trim()).filter(Boolean);
    }

    if (!currentTechs.includes(value.trim())) {
      const updatedTechs = [...currentTechs, value.trim()];
      updateEntry(expId, "technologies", updatedTechs);
    }
    setTechInput((prev) => ({ ...prev, [expId]: "" }));
  };

  const handleRemoveTech = (expId: string | number | undefined, techName: string) => {
    if (!expId) return;
    const exp = experience.find((e) => e.id === expId);
    if (!exp) return;

    let currentTechs: string[] = [];
    if (Array.isArray(exp.technologies)) {
      currentTechs = exp.technologies;
    }

    const updatedTechs = currentTechs.filter((t) => t !== techName);
    updateEntry(expId, "technologies", updatedTechs);
  };

  // AI Achievement Suggester
  const handleGenerateAchievements = (expId: string | number | undefined, title: string) => {
    if (!expId || !title) return;
    const suggestions: Record<string, string> = {
      engineer: "• Developed scalable web architectures resulting in 40% performance gain.\n• Maintained 99.9% uptime by migrating APIs to AWS serverless setups.\n• Led code reviews and mentored junior engineering squad members.",
      designer: "• Conducted 15+ user interview programs to streamline conversion rates by 22%.\n• Designed high-fidelity design prototypes and unified product style system.\n• Collaborated with engineering leads to enforce pixel-perfect CSS components.",
      developer: "• Authored secure REST endpoints and integrated responsive React components.\n• Implemented Jest tests to boost test coverage metrics up to 88%.\n• Automated deployment scripts to cut pipeline staging cycles in half.",
    };

    let matched = suggestions.engineer;
    const lowerTitle = title.toLowerCase();
    if (lowerTitle.includes("design") || lowerTitle.includes("ux") || lowerTitle.includes("ui")) {
      matched = suggestions.designer;
    } else if (lowerTitle.includes("dev") || lowerTitle.includes("frontend") || lowerTitle.includes("backend")) {
      matched = suggestions.developer;
    }

    const exp = experience.find((e) => e.id === expId);
    if (exp) {
      updateEntry(expId, "description", (exp.description || "") + "\n" + matched);
    }
  };

  const isComplete = experience.length > 0;

  return (
    <section className="bg-white rounded-2xl border border-slate-200/80 shadow-sm transition-all duration-300 overflow-hidden" id="experience">
      {/* Collapsible Header */}
      <button
        type="button"
        onClick={onToggleExpand}
        className="w-full flex items-center justify-between p-5 text-left hover:bg-slate-50/50 transition-colors focus:outline-none focus:ring-2 focus:ring-primary/20 cursor-pointer"
        aria-expanded={isExpanded}
      >
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-primary/5 flex items-center justify-center text-primary shrink-0">
            <span className="material-symbols-outlined text-xl">work</span>
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-800 leading-tight">Work History</h3>
            <p className="text-xs text-slate-500 mt-0.5">Document your career achievements</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {isComplete ? (
            <span className="px-2.5 py-0.5 bg-emerald-50 text-emerald-600 text-xs font-semibold rounded-full flex items-center gap-1 border border-emerald-100/50">
              <span className="material-symbols-outlined text-sm font-bold">check_circle</span>
              {experience.length} {experience.length === 1 ? "Role" : "Roles"}
            </span>
          ) : (
            <span className="px-2.5 py-0.5 bg-amber-50 text-amber-700 text-xs font-semibold rounded-full border border-amber-100/50 animate-pulse">
              Required
            </span>
          )}
          <span className={`material-symbols-outlined text-slate-400 transition-transform ${isExpanded ? "rotate-180" : ""}`}>
            expand_more
          </span>
        </div>
      </button>

      {/* Expanded Content */}
      <div
        className={`transition-all duration-500 ease-in-out overflow-hidden ${
          isExpanded ? "max-h-[2500px] opacity-100 border-t border-slate-100" : "max-h-0 opacity-0 pointer-events-none"
        }`}
      >
        <div className="p-5 sm:p-6 bg-white space-y-6">
          <div className="flex justify-end">
            <button
              onClick={addEntry}
              type="button"
              className="px-4 py-2 bg-primary/5 text-primary text-xs font-bold rounded-lg hover:bg-primary hover:text-white transition-all border border-primary/10 flex items-center justify-center gap-1.5 min-h-[44px] cursor-pointer"
            >
              <span className="material-symbols-outlined text-sm">add</span>
              Add Experience
            </button>
          </div>

          <div className="space-y-8">
            {experience.length === 0 ? (
              <div className="text-center py-10 border border-dashed border-slate-205 rounded-xl bg-slate-50/50">
                <span className="material-symbols-outlined text-3xl text-slate-350 mb-2 block">work_history</span>
                <span className="text-sm font-bold text-slate-700 block mb-0.5">No experience details added yet</span>
                <span className="text-xs text-slate-500 block mb-4">Adding work history increases shortlisting chance by 4x.</span>
                <button
                  type="button"
                  onClick={addEntry}
                  className="text-primary text-xs font-bold hover:underline cursor-pointer min-h-[44px] px-4"
                >
                  Add first experience card
                </button>
              </div>
            ) : (
              experience.map((exp, idx) => {
                const techs = Array.isArray(exp.technologies)
                  ? exp.technologies
                  : typeof exp.technologies === "string"
                  ? exp.technologies.split(",").map((t) => t.trim()).filter(Boolean)
                  : [];

                return (
                  <div
                    key={exp.id}
                    className="relative bg-slate-50/30 hover:bg-slate-50/70 border border-slate-200 rounded-xl p-5 transition-all group"
                  >
                    {/* Reorder and Delete Actions */}
                    <div className="absolute top-3 right-3 flex items-center gap-1.5 opacity-100 lg:opacity-0 lg:group-hover:opacity-100 transition-opacity">
                      <button
                        type="button"
                        disabled={idx === 0}
                        onClick={() => moveEntry(idx, "up")}
                        className="w-11 h-11 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-500 hover:text-primary disabled:opacity-30 cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-base">arrow_upward</span>
                      </button>
                      <button
                        type="button"
                        disabled={idx === experience.length - 1}
                        onClick={() => moveEntry(idx, "down")}
                        className="w-11 h-11 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-500 hover:text-primary disabled:opacity-30 cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-base">arrow_downward</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => removeEntry(exp.id)}
                        className="w-11 h-11 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-red-500 hover:text-red-700 hover:bg-red-50 cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-base">delete</span>
                      </button>
                    </div>

                    <div className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">Job Title</label>
                          <input
                            type="text"
                            value={exp.title || ""}
                            onChange={(e) => updateEntry(exp.id, "title", e.target.value)}
                            placeholder="e.g. Lead Frontend Developer"
                            className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">Company Name</label>
                          <input
                            type="text"
                            value={exp.company || ""}
                            onChange={(e) => updateEntry(exp.id, "company", e.target.value)}
                            placeholder="e.g. Google"
                            className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">Employment Type</label>
                          <select
                            value={exp.employment_type || "Full-time"}
                            onChange={(e) => updateEntry(exp.id, "employment_type", e.target.value)}
                            className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700"
                          >
                            {employmentTypes.map((t) => (
                              <option key={t} value={t}>
                                {t}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">Location</label>
                          <input
                            type="text"
                            value={exp.location || ""}
                            onChange={(e) => updateEntry(exp.id, "location", e.target.value)}
                            placeholder="San Francisco, CA"
                            className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 placeholder:text-slate-400"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">Start Date</label>
                          <input
                            type="date"
                            value={exp.start_date || ""}
                            onChange={(e) => updateEntry(exp.id, "start_date", e.target.value)}
                            className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">End Date</label>
                          <input
                            type="date"
                            value={exp.end_date || ""}
                            disabled={exp.current}
                            onChange={(e) => updateEntry(exp.id, "end_date", e.target.value)}
                            className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-700 disabled:opacity-50"
                          />
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-3.5 bg-white border border-slate-200 rounded-xl">
                        <div>
                          <p className="text-xs font-bold text-slate-800">I currently work here</p>
                          <p className="text-xs text-slate-500 font-medium mt-0.5">This will automatically mark end date as present</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            updateEntry(exp.id, "current", !exp.current);
                            if (!exp.current) {
                              updateEntry(exp.id, "end_date", "");
                            }
                          }}
                          className={`relative w-12 h-6 rounded-full transition-colors flex-shrink-0 min-h-[44px] cursor-pointer ${
                            exp.current ? "bg-primary" : "bg-slate-200"
                          }`}
                        >
                          <span
                            className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${
                              exp.current ? "right-0.5" : "left-0.5"
                            }`}
                          ></span>
                        </button>
                      </div>

                      {/* Description & AI suggestor */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <label className="block text-xs font-semibold text-slate-500">Responsibilities & Achievements</label>
                          <button
                            type="button"
                            onClick={() => handleGenerateAchievements(exp.id, exp.title || "")}
                            className="text-xs font-bold text-primary flex items-center gap-0.5 hover:underline cursor-pointer min-h-[44px] px-2"
                          >
                            <span className="material-symbols-outlined text-sm font-bold animate-pulse">star</span>
                            Generate with AI
                          </button>
                        </div>
                        <textarea
                          value={exp.description || ""}
                          onChange={(e) => updateEntry(exp.id, "description", e.target.value)}
                          rows={4}
                          placeholder="Detail your responsibilities and achievements..."
                          className="w-full bg-white border border-slate-200 rounded-xl py-3 px-4 text-sm font-medium text-slate-700 focus:border-primary focus:ring-1 focus:ring-primary/20 outline-none leading-relaxed resize-none"
                        />
                      </div>

                      {/* Technologies tags used */}
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-2">Technologies Used</label>
                        <div className="flex flex-wrap gap-2 mb-2">
                          {techs.map((tech) => (
                            <span
                              key={tech}
                              className="flex items-center gap-1 bg-white border border-slate-200 text-slate-600 pl-2.5 pr-1 py-1 rounded-lg text-xs font-medium"
                            >
                              {tech}
                              <button
                                type="button"
                                onClick={() => handleRemoveTech(exp.id, tech)}
                                className="hover:text-red-500 ml-1 text-slate-400 flex items-center justify-center cursor-pointer min-h-[44px] min-w-[44px]"
                              >
                                <span className="material-symbols-outlined text-xs">close</span>
                              </button>
                            </span>
                          ))}
                        </div>
                        <input
                          type="text"
                          value={techInput[exp.id as string] || ""}
                          onChange={(e) => setTechInput((prev) => ({ ...prev, [exp.id as string]: e.target.value }))}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              e.preventDefault();
                              handleAddTech(exp.id, techInput[exp.id as string]);
                            }
                          }}
                          placeholder="Type a technology (e.g. React) and press Enter..."
                          className="w-full px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-xs outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 font-medium text-slate-750 placeholder:text-slate-400"
                        />
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
