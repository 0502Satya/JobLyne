"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { logoutAction, getCreditBalanceAction } from "@/features/auth/actions";
import { getRecruiterDashboardAction, postRecruiterCandidateAction } from "@/features/recruiter/actions";

interface Candidate {
  id: string;
  user_id?: string;
  name: string;
  role: string;
  avatarColor: string;
  matchScore: number;
  skills: string[];
  location: string;
  experience: string;
  bio: string;
  status: "Sourced" | "Interviewing" | "Offered" | "Placed";
  isShortlisted?: boolean;
  interviewStatus?: "Invited" | "None";
  isLocked?: boolean;
  email?: string;
  phone?: string;
  whatsapp?: string;
}

export default function RecruiterDashboardPage() {
  const router = useRouter();
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [credits, setCredits] = useState<{ available_credits: number; credit_type_name: string } | null>(null);

  const [stats, setStats] = useState({
    total_candidates: 0,
    active_pipelines: 0,
    interviewing_stages: 0,
    placements_made: 0
  });

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [activePipelineFilter, setActivePipelineFilter] = useState<"All" | "Sourced" | "Interviewing" | "Offered" | "Placed">("All");

  const loadDashboardData = async (query?: string) => {
    try {
      const data = await getRecruiterDashboardAction(query);
      if (data.error) {
        setError(data.error);
      } else {
        setCandidates((data.candidates || []).map((c: any) => ({
          ...c,
          isLocked: c.isLocked !== undefined ? c.isLocked : true,
          email: c.email || `${c.name.toLowerCase().replace(/\s+/g, ".")}@example.com`,
          phone: c.phone || `+1 (555) 234-${Math.floor(1000 + Math.random() * 9000)}`,
          whatsapp: c.whatsapp || `+1 (555) 234-${Math.floor(1000 + Math.random() * 9000)}`
        })));
        setStats(data.statistics || {
          total_candidates: 0,
          active_pipelines: 0,
          interviewing_stages: 0,
          placements_made: 0
        });
      }

      // Fetch sourcing credits
      const creditsRes = await getCreditBalanceAction();
      if (!creditsRes.error) {
        setCredits({
          available_credits: creditsRes.available_credits,
          credit_type_name: creditsRes.credit_type_name
        });
      }
    } catch (err) {
      setError("An unexpected connection error occurred.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      loadDashboardData(searchQuery);
    }, 300);

    return () => clearTimeout(delayDebounceFn);
  }, [searchQuery]);

  // Toggle Shortlist State
  const toggleShortlist = async (id: string) => {
    // Optimistic UI update
    setCandidates(prev => 
      prev.map(c => c.id === id ? { ...c, isShortlisted: !c.isShortlisted } : c)
    );

    const res = await postRecruiterCandidateAction(id, 'toggle_shortlist');
    if (res.error) {
      // Revert if error
      setCandidates(prev => 
        prev.map(c => c.id === id ? { ...c, isShortlisted: !c.isShortlisted } : c)
      );
      alert(res.error);
    } else {
      // Sync exact state from DB
      setCandidates(prev => 
        prev.map(c => c.id === id ? { ...c, isShortlisted: res.isShortlisted } : c)
      );
    }
  };

  // Invite for Interview State
  const handleInvite = async (id: string) => {
    // Optimistic UI update
    setCandidates(prev =>
      prev.map(c => c.id === id ? { ...c, interviewStatus: "Invited", status: "Interviewing" } : c)
    );
    setStats(prev => ({
      ...prev,
      interviewing_stages: prev.interviewing_stages + 1
    }));

    const res = await postRecruiterCandidateAction(id, 'invite');
    if (res.error) {
      alert(res.error);
      loadDashboardData();
    } else {
      loadDashboardData();
    }
  };

  // Unlock Profile Coordinates
  const handleUnlockProfile = async (candidateId: string) => {
    if (!credits || credits.available_credits < 1) {
      alert("Insufficient talent credits! Please navigate to the Billing Center to fund your wallet and upgrade your recruiter plan.");
      return;
    }

    const res = await postRecruiterCandidateAction(candidateId, 'unlock');
    if (res.error) {
      alert(res.error);
    } else {
      setCredits(prev => prev ? { ...prev, available_credits: res.available_credits } : null);
      setCandidates(prev =>
        prev.map(c =>
          c.id === candidateId
            ? {
                ...c,
                isLocked: false,
                email: res.email,
                phone: res.phone,
                whatsapp: res.whatsapp
              }
            : c
        )
      );
      alert("Profile contact details successfully unlocked! 1 credit deducted.");
    }
  };

  // Promote Pipeline Stage
  const promoteCandidateStage = async (id: string) => {
    const res = await postRecruiterCandidateAction(id, 'advance');
    if (res.error) {
      alert(res.error);
    } else {
      loadDashboardData();
    }
  };

  // Start chat with candidate
  const handleStartChat = async (recipientId?: string) => {
    if (!recipientId) {
      alert("This candidate does not have a user profile established yet.");
      return;
    }

    const { startThreadAction } = await import("@/features/auth/actions");
    const res = await startThreadAction(recipientId);
    if (res.error) {
      alert(res.error);
    } else if (res.thread_id) {
      router.push(`/recruiter/messages?thread=${res.thread_id}`);
    }
  };

  // Export Shortlisted Candidates to CSV
  const handleExportShortlistCSV = () => {
    const shortlisted = candidates.filter(c => c.isShortlisted);
    if (shortlisted.length === 0) {
      alert("No candidates have been shortlisted yet. Star some profiles to shortlist them first!");
      return;
    }

    const headers = ["Candidate ID", "Name", "Role", "Match Score %", "Experience", "Location", "Sourcing Status", "Email", "Phone"];
    const rows = shortlisted.map(c => [
      c.id,
      `"${c.name.replace(/"/g, '""')}"`,
      `"${c.role.replace(/"/g, '""')}"`,
      c.matchScore,
      `"${c.experience.replace(/"/g, '""')}"`,
      `"${c.location.replace(/"/g, '""')}"`,
      c.status,
      c.isLocked ? "Locked" : c.email || "",
      c.isLocked ? "Locked" : c.phone || ""
    ]);

    const csvContent = [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `shortlist_export_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };


  // Filter candidate pool
  const filteredCandidates = candidates.filter(c => {
    const term = searchQuery.toLowerCase();
    const matchesSearch = c.name.toLowerCase().includes(term) || 
                          c.role.toLowerCase().includes(term) || 
                          c.skills.some(s => s.toLowerCase().includes(term)) ||
                          c.location.toLowerCase().includes(term);
    const matchesPipeline = activePipelineFilter === "All" || c.status === activePipelineFilter;
    return matchesSearch && matchesPipeline;
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-bg text-text flex flex-col justify-center items-center p-6">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mb-4"></div>
        <p className="text-muted font-bold text-sm tracking-widest uppercase">Loading Sourcing Data...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-bg text-text flex flex-col justify-center items-center p-6 text-center max-w-md mx-auto">
        <span className="material-symbols-outlined text-red-500 text-6xl mb-4">gavel</span>
        <h2 className="text-2xl font-black mb-2">Access Restrained</h2>
        <p className="text-muted text-sm font-semibold mb-6">{error}</p>
        <div className="flex gap-4">
          <Link href="/" className="px-6 py-3 bg-primary text-surface rounded-2xl font-black text-xs min-h-[44px] flex items-center justify-center">
            Back Home
          </Link>
          <button onClick={() => logoutAction()} className="px-6 py-3 bg-surface border border-border text-text rounded-2xl font-black text-xs min-h-[44px]">
            Logout
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-bg text-text transition-colors flex flex-col font-sans">
      
      {/* Sticky Premium Header */}
      <header className="flex items-center justify-between border-b border-border bg-surface px-6 md:px-12 py-4 sticky top-0 z-50 transition-all">
        <div className="flex items-center gap-6">
          <Link href="/" className="flex items-center gap-2 text-primary font-black hover:opacity-90 transition-opacity">
            <span className="material-symbols-outlined text-3xl">hub</span>
            <span className="text-2xl tracking-tight">JobLyne</span>
          </Link>
          <div className="h-6 w-px bg-border hidden md:block"></div>
          <span className="bg-primary/10 text-primary text-[10px] font-black uppercase tracking-widest px-3 py-1.5 rounded-full hidden md:inline-block">Recruiter Portal</span>
        </div>
        <div className="flex items-center gap-4">
          <Link href="/recruiter/billing" className="text-xs font-black text-muted hover:text-primary transition-colors uppercase tracking-widest px-4 py-3 rounded-xl hover:bg-primary/5 active:scale-[0.98] min-h-[44px] flex items-center gap-2 border border-dashed border-border">
            <span className="material-symbols-outlined text-[18px] text-amber-500">credit_card</span>
            Billing Center
            {credits && (
              <span className="bg-amber-500/10 text-amber-400 text-[10px] font-extrabold px-2 py-0.5 rounded-full border border-amber-500/20">
                {credits.available_credits} Credits
              </span>
            )}
          </Link>
          <div className="h-6 w-px bg-border hidden md:block"></div>
          <Link href="/recruiter/messages" className="text-xs font-black text-muted hover:text-primary transition-colors uppercase tracking-widest px-4 py-3 rounded-xl hover:bg-primary/5 active:scale-[0.98] min-h-[44px] flex items-center gap-2">
            <span className="material-symbols-outlined text-[18px]">chat</span>
            Messages
          </Link>
          <div className="h-6 w-px bg-border hidden md:block"></div>
          <div className="flex items-center gap-3">
            <div className="size-11 rounded-2xl bg-gradient-to-tr from-primary to-[#4c33cf] text-white flex items-center justify-center font-black shadow-lg shadow-primary/20 cursor-pointer">
              RC
            </div>
            <button 
              onClick={() => logoutAction()} 
              className="text-xs font-black text-muted hover:text-red-500 transition-colors uppercase tracking-widest px-4 py-3 rounded-xl hover:bg-red-500/5 active:scale-[0.98] min-h-[44px]"
            >
              Logout
            </button>
          </div>
        </div>
      </header>

      <main className="p-6 md:p-12 max-w-7xl mx-auto w-full flex-1 space-y-8 box-sizing">
        
        {/* Welcome Section */}
        <div className="space-y-2">
          <h1 className="text-3xl font-black tracking-tight text-text">Recruiter Command Center</h1>
          <p className="text-muted text-sm font-semibold">Track sourced talent, optimize active interview funnels, and place candidates.</p>
        </div>

        {/* Pipeline Analytics Board */}
        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { label: "Total Candidates", value: stats.total_candidates, icon: "person", color: "text-[#3b82f6]", bg: "bg-[#3b82f6]/10", border: "border-[#3b82f6]/20", pct: "Database" },
            { label: "Active Pipelines", value: stats.active_pipelines, icon: "reorder", color: "text-[#8b5cf6]", bg: "bg-[#8b5cf6]/10", border: "border-[#8b5cf6]/20", pct: "Inbound" },
            { label: "Interviewing Stages", value: stats.interviewing_stages, icon: "event", color: "text-[#f59e0b]", bg: "bg-[#f59e0b]/10", border: "border-[#f59e0b]/20", pct: "Active" },
            { label: "Placements Made", value: stats.placements_made, icon: "verified", color: "text-emerald-500", bg: "bg-emerald-500/10", border: "border-emerald-500/20", pct: "Goal met" },
          ].map((stat, i) => (
            <div key={i} className={`bg-surface border ${stat.border} p-6 rounded-3xl shadow-sm hover:shadow-lg transition-all duration-300 relative group`}>
              <div className="flex justify-between items-start mb-4">
                <div className={`size-12 rounded-xl ${stat.bg} flex items-center justify-center transition-transform group-hover:scale-110 duration-300`}>
                  <span className={`material-symbols-outlined text-[24px] ${stat.color}`}>{stat.icon}</span>
                </div>
                <span className="text-[10px] font-black text-emerald-500 bg-emerald-500/10 px-2.5 py-1 rounded-full uppercase tracking-wider">{stat.pct}</span>
              </div>
              <h4 className="text-3xl font-black text-text tracking-tight">{stat.value}</h4>
              <p className="text-xs font-black text-muted uppercase tracking-widest mt-1">{stat.label}</p>
            </div>
          ))}
        </section>

        {/* Visual Pipeline Funnel Selector */}
        <section className="bg-surface border border-border p-6 rounded-card shadow-sm space-y-4">
          <h3 className="text-lg font-black tracking-tight text-text">Pipeline Workflow Stages</h3>
          <div className="flex flex-col md:flex-row gap-2 w-full">
            {(["All", "Sourced", "Interviewing", "Offered", "Placed"] as const).map((stage) => {
              const count = stage === "All" ? candidates.length : candidates.filter(c => c.status === stage).length;
              return (
                <button
                  key={stage}
                  onClick={() => setActivePipelineFilter(stage)}
                  className={`flex-1 py-3 px-4 rounded-2xl text-xs font-black uppercase tracking-wider border transition-all min-h-[48px] flex justify-between items-center active:scale-[0.98] ${
                    activePipelineFilter === stage
                      ? "bg-primary border-primary text-surface shadow-lg shadow-primary/20"
                      : "border-border hover:border-primary/30 text-text hover:bg-bg"
                  }`}
                >
                  <span>{stage === "All" ? "Full Funnel" : stage}</span>
                  <span className={`size-6 rounded-full flex items-center justify-center text-[10px] font-black ${
                    activePipelineFilter === stage ? "bg-surface/20 text-surface" : "bg-bg text-muted"
                  }`}>{count}</span>
                </button>
              );
            })}
          </div>
        </section>

        {/* AI Talent Match Sandbox Area */}
        <section className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
          
          {/* Left 2 Columns: Candidate Interactive Search Panel */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 flex-wrap">
              <h3 className="text-xl font-black tracking-tight">AI Candidate Sourcing Pool</h3>
              
              <div className="flex items-center gap-2.5 w-full sm:w-auto">
                {/* Search bar */}
                <div className="relative flex-1 sm:w-64">
                  <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-muted">search</span>
                  <input 
                    type="text" 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Query skills, roles, name..."
                    className="w-full pl-10 pr-4 py-3 bg-surface border border-border rounded-2xl outline-none focus:ring-2 focus:ring-primary font-medium text-xs min-h-[44px]"
                  />
                </div>
                <button
                  onClick={handleExportShortlistCSV}
                  className="bg-surface hover:bg-bg border border-border text-text font-black text-xs px-4 py-3 rounded-2xl transition-all min-h-[44px] flex items-center gap-1.5 active:scale-95 whitespace-nowrap"
                  title="Export shortlisted candidates to CSV"
                >
                  <span className="material-symbols-outlined text-[18px]">download</span>
                  Export Shortlist
                </button>
              </div>
            </div>

            {/* Candidate list cards */}
            <div className="space-y-4">
              {filteredCandidates.map((c) => (
                <div key={c.id} className="bg-surface border border-border p-6 md:p-8 rounded-card shadow-sm hover:border-primary/40 transition-all flex flex-col md:flex-row justify-between items-start gap-6 relative overflow-hidden">
                  
                  {/* Matching rating strip */}
                  <div className="absolute top-0 left-0 w-2 h-full bg-primary/20"></div>
                  
                  <div className="space-y-4 flex-1 pl-4 md:pl-2">
                    
                    {/* Header info */}
                    <div className="flex items-start gap-4 flex-wrap sm:flex-nowrap">
                      <div className={`size-14 rounded-2xl ${c.avatarColor} text-white flex items-center justify-center font-black text-lg shadow-md shrink-0`}>
                        {c.name.substring(0, 2).toUpperCase()}
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center gap-3 flex-wrap">
                          <h4 className="text-xl font-black text-text leading-tight">{c.name}</h4>
                          <span className="bg-primary/10 text-primary text-xs font-black px-2.5 py-1 rounded-full flex items-center gap-1">
                            <span className="material-symbols-outlined text-sm">bolt</span>
                            {c.matchScore}% Match
                          </span>
                          <span className={`text-[10px] font-black px-2.5 py-1 rounded-full uppercase tracking-wider ${
                            c.status === "Sourced" ? "bg-blue-500/10 text-blue-500" :
                            c.status === "Interviewing" ? "bg-warning/10 text-warning" :
                            c.status === "Offered" ? "bg-purple-500/10 text-purple-500" : "bg-emerald-500/10 text-emerald-500"
                          }`}>{c.status}</span>
                        </div>
                        <p className="text-xs text-muted font-bold tracking-tight">{c.role} &bull; {c.experience} Exp</p>
                      </div>
                    </div>

                    {/* Bio */}
                    <p className="text-sm font-medium text-muted leading-relaxed max-w-2xl">{c.bio}</p>

                    {/* Skills list */}
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {c.skills.map((skill, idx) => (
                        <span key={idx} className="bg-bg text-text font-black text-[10px] uppercase px-2.5 py-1 rounded-full border border-border">{skill}</span>
                      ))}
                    </div>

                    {/* Location coordinates */}
                    <div className="flex items-center gap-2 text-xs text-muted font-bold pt-1">
                      <span className="material-symbols-outlined text-[14px]">location_on</span>
                      {c.location}
                    </div>

                    {/* Contact details masking & unlocking check */}
                    <div className="mt-4 pt-4 border-t border-border/60 w-full">
                      {c.isLocked ? (
                        <div className="bg-bg/60 backdrop-blur-sm border border-dashed border-border p-4 rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                          <div className="space-y-1">
                            <span className="text-[10px] text-muted font-bold uppercase tracking-widest block">Contact Info</span>
                            <div className="flex items-center gap-2 text-xs text-slate-500 font-semibold">
                              <span className="material-symbols-outlined text-[14px]">mail</span>
                              <span>e***@gmail.com</span>
                              <span className="text-slate-600">&bull;</span>
                              <span className="material-symbols-outlined text-[14px]">phone</span>
                              <span>+1 (555) ***-****</span>
                            </div>
                          </div>
                          <button
                            onClick={() => handleUnlockProfile(c.id)}
                            className="bg-amber-400 hover:bg-amber-500 text-slate-950 font-black text-xs px-4 py-2.5 rounded-xl transition-all flex items-center gap-2 shadow-lg shadow-amber-500/10 active:scale-95 min-h-[44px]"
                          >
                            <span className="material-symbols-outlined text-[16px]">key</span>
                            Unlock Details (1 Credit)
                          </button>
                        </div>
                      ) : (
                        <div className="bg-emerald-500/[0.02] border border-emerald-500/15 p-4 rounded-2xl flex flex-col gap-2">
                          <span className="text-[10px] text-emerald-500 font-bold uppercase tracking-widest block">Unlocked Coordinates</span>
                          <div className="flex flex-wrap gap-4 text-xs font-semibold text-text">
                            <div className="flex items-center gap-2">
                              <span className="material-symbols-outlined text-[15px] text-emerald-400">mail</span>
                              <a href={`mailto:${c.email}`} className="hover:underline hover:text-primary transition-colors">{c.email}</a>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="material-symbols-outlined text-[15px] text-emerald-400">phone</span>
                              <a href={`tel:${c.phone}`} className="hover:underline hover:text-primary transition-colors">{c.phone}</a>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="material-symbols-outlined text-[15px] text-emerald-400">chat</span>
                              <a href={`https://wa.me/${c.phone?.replace(/[^0-9]/g, '')}`} target="_blank" rel="noopener noreferrer" className="hover:underline hover:text-primary transition-colors">WhatsApp</a>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                  </div>

                  {/* Actions column */}
                  <div className="border-t md:border-t-0 md:border-l border-border pt-4 md:pt-0 md:pl-6 w-full md:w-56 shrink-0 flex flex-col gap-2.5">
                    
                    <button
                      onClick={() => handleInvite(c.id)}
                      disabled={c.interviewStatus === "Invited"}
                      className={`w-full py-3.5 px-4 rounded-2xl font-black text-xs flex items-center justify-center gap-1.5 min-h-[48px] transition-all active:scale-[0.98] ${
                        c.interviewStatus === "Invited"
                          ? "bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 cursor-default"
                          : "bg-primary text-surface hover:scale-[1.02] shadow-lg shadow-primary/10"
                      }`}
                    >
                      <span className="material-symbols-outlined text-sm">
                        {c.interviewStatus === "Invited" ? "check_circle" : "mail"}
                      </span>
                      {c.interviewStatus === "Invited" ? "Invited to Apply" : "Invite to Apply"}
                    </button>

                    <button 
                      onClick={() => promoteCandidateStage(c.id)}
                      className="w-full bg-bg hover:bg-border text-text font-black py-3.5 px-4 rounded-2xl text-xs transition-all min-h-[48px] flex items-center justify-center gap-1.5 active:scale-[0.98]"
                    >
                      <span className="material-symbols-outlined text-sm">arrow_forward</span>
                      Advance Funnel
                    </button>

                    <button
                      onClick={() => handleStartChat(c.user_id)}
                      className="w-full bg-surface border border-border hover:bg-bg text-text font-black py-3.5 px-4 rounded-2xl text-xs transition-all min-h-[48px] flex items-center justify-center gap-1.5 active:scale-[0.98]"
                    >
                      <span className="material-symbols-outlined text-sm">chat</span>
                      Send Message
                    </button>

                    <button
                      onClick={() => toggleShortlist(c.id)}
                      className={`w-full py-3.5 px-4 rounded-2xl font-black text-xs transition-all min-h-[48px] border ${
                        c.isShortlisted 
                          ? "bg-warning/10 border-warning/30 text-warning" 
                          : "border-border hover:bg-bg text-text"
                      }`}
                    >
                      {c.isShortlisted ? "⭐ Shortlisted" : "Star Profile"}
                    </button>

                  </div>

                </div>
              ))}

              {filteredCandidates.length === 0 && (
                <div className="bg-surface border border-border p-12 rounded-card text-center space-y-4">
                  <span className="material-symbols-outlined text-6xl text-muted">search_off</span>
                  <div className="space-y-1">
                    <h4 className="text-lg font-black">No matching candidates in pipeline</h4>
                    <p className="text-sm text-muted">Try modifying your query tags or pipeline filters.</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Recruiter Sourcing Intelligence */}
          <div className="space-y-6">
            
            <div className="bg-gradient-to-br from-primary/10 to-[#4c33cf]/10 border-2 border-primary/20 rounded-card p-8 space-y-6 relative overflow-hidden">
              <h3 className="text-xl font-black text-primary tracking-tight">Sourcing Analytics</h3>
              <p className="text-muted font-medium text-sm leading-relaxed">
                Your sourced placements are performing <strong>12% higher</strong> than platform averages this month. Keep identifying matching skills to acquire the "Gold Elite Recruiter" emblem.
              </p>
              
              <div className="space-y-3 pt-2">
                <div>
                  <div className="flex justify-between text-xs font-black uppercase mb-1">
                    <span>Vetting Accuracy</span>
                    <span>94%</span>
                  </div>
                  <div className="h-2 w-full bg-primary/20 rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full" style={{ width: "94%" }}></div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs font-black uppercase mb-1">
                    <span>Interview Conversions</span>
                    <span>72%</span>
                  </div>
                  <div className="h-2 w-full bg-primary/20 rounded-full overflow-hidden">
                    <div className="h-full bg-[#8b5cf6] rounded-full" style={{ width: "72%" }}></div>
                  </div>
                </div>
              </div>

              <span className="material-symbols-outlined absolute -bottom-6 -right-6 text-9xl text-primary/5">insights</span>
            </div>

            <div className="bg-surface border border-border p-6 rounded-card shadow-sm space-y-4">
              <h4 className="font-black text-text text-base">Quick Sourcing Actions</h4>
              <div className="space-y-3">
                <button 
                  onClick={() => alert("Verification check queued! Automated reference checking has been initialized for your active pipeline.")}
                  className="w-full flex items-center gap-3 p-4 rounded-2xl border border-border hover:border-primary/40 transition-all text-left group min-h-[48px] active:scale-[0.98]"
                >
                  <span className="material-symbols-outlined text-primary group-hover:scale-110 transition-transform">bolt</span>
                  <div className="min-w-0">
                    <h5 className="font-black text-sm text-text">Verify Candidate Experience</h5>
                    <p className="text-xs text-muted font-medium truncate">Integrate automated work experience auditing.</p>
                  </div>
                </button>
                <button 
                  onClick={() => alert("Skills filter enabled! Sourcing pool has been prioritized by technical matching.")}
                  className="w-full flex items-center gap-3 p-4 rounded-2xl border border-border hover:border-primary/40 transition-all text-left group min-h-[48px] active:scale-[0.98]"
                >
                  <span className="material-symbols-outlined text-primary group-hover:scale-110 transition-transform">list</span>
                  <div className="min-w-0">
                    <h5 className="font-black text-sm text-text">Pre-Vetted Talent Pools</h5>
                    <p className="text-xs text-muted font-medium truncate">Explore candidate list categorized by dynamic scores.</p>
                  </div>
                </button>
              </div>
            </div>

          </div>

        </section>

      </main>
    </div>
  );
}


