"use client";

import React, { useEffect, useState, useRef, useMemo } from "react";
import { getCandidateProfileAction, updateCandidateProfileAction } from "@/features/auth/actions";
import PersonalInfoSection from "@/features/dashboard/components/profile/PersonalInfoSection";
import AboutMeSection from "@/features/dashboard/components/profile/AboutMeSection";
import JobPreferencesSection from "@/features/dashboard/components/profile/JobPreferencesSection";
import WorkExperienceSection from "@/features/dashboard/components/profile/WorkExperienceSection";
import EducationSection from "@/features/dashboard/components/profile/EducationSection";
import SkillsSection from "@/features/dashboard/components/profile/SkillsSection";
import ProjectsSection from "@/features/dashboard/components/profile/ProjectsSection";
import CertificationsSection from "@/features/dashboard/components/profile/CertificationsSection";
import ResumeBuilderSection from "@/features/dashboard/components/profile/ResumeBuilderSection";
import PrivacySettingsSection from "@/features/dashboard/components/profile/PrivacySettingsSection";
import UnsavedChangesBar from "@/features/dashboard/components/profile/UnsavedChangesBar";
import Toast from "@/features/dashboard/components/profile/Toast";
import ProfileInfoCard from "@/features/dashboard/components/profile/ProfileInfoCard";

import { Profile, WorkExperience, Education, Project, Certification } from "@/types/profile";

const SECTIONS = [
  { id: "personal", label: "Personal Info", icon: "person" },
  { id: "about", label: "About Me", icon: "description" },
  { id: "preferences", label: "Preferences", icon: "tune" },
  { id: "experience", label: "Experience", icon: "work" },
  { id: "education", label: "Education", icon: "school" },
  { id: "skills", label: "Skills", icon: "bolt" },
  { id: "projects", label: "Projects", icon: "folder_open" },
  { id: "certifications", label: "Certifications", icon: "workspace_premium" },
  { id: "resume", label: "Resume Builder", icon: "analytics" },
  { id: "privacy", label: "Privacy Settings", icon: "shield" },
];

function isProfileDirty(a: Profile | null, b: Profile | null): boolean {
  if (a === b) return false;
  if (!a || !b) return true;

  // Key primitive fields to check first (shallow check)
  const primitiveKeys: (keyof Profile)[] = [
    "id", "full_name", "first_name", "middle_name", "last_name", "username",
    "email", "phone", "whatsapp_number", "location", "city", "country",
    "hometown", "pincode", "headline", "bio", "summary", "experience_years",
    "notice_period", "expected_salary", "current_salary", "currency",
    "resume_file_url", "gender", "date_of_birth", "marital_status",
    "current_company", "current_designation", "industry", "functional_area",
    "is_open_to_opportunities", "desired_titles", "completeness",
    "profile_photo_url", "member_since", "nationality", "preferred_company_size",
    "open_to_relocation", "open_to_international"
  ];

  for (const key of primitiveKeys) {
    if (a[key] !== b[key]) {
      return true;
    }
  }

  // Complex fields (deep check using stringify)
  const complexKeys: (keyof Profile)[] = [
    "work_mode", "preferred_locations", "social_links", "experience",
    "education", "projects", "certifications", "skills", "languages",
    "privacy_settings"
  ];

  for (const key of complexKeys) {
    const valA = a[key];
    const valB = b[key];
    if (JSON.stringify(valA) !== JSON.stringify(valB)) {
      return true;
    }
  }

  return false;
}

export default function ProfilePage() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [originalProfile, setOriginalProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [fetchError, setFetchError] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: "success" | "error" } | null>(null);
  const [activeSection, setActiveSection] = useState("personal");

  const dirtyCheckTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // State to manage Collapsible Sections
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    personal: true,
    about: true,
    preferences: true,
    experience: false,
    education: false,
    skills: false,
    projects: false,
    certifications: false,
    resume: false,
    privacy: false,
  });

  const handleSectionToggle = (sectionId: string) => {
    setExpandedSections((prev) => ({
      ...prev,
      [sectionId]: !prev[sectionId],
    }));
  };

  const handleNavClick = (sectionId: string) => {
    setExpandedSections((prev) => ({ ...prev, [sectionId]: true }));
    setTimeout(() => {
      const el = document.getElementById(sectionId);
      if (el) {
        el.scrollIntoView({ behavior: "smooth" });
      }
    }, 100);
  };

  async function fetchProfile() {
    setLoading(true);
    setFetchError(false);
    const data = await getCandidateProfileAction();
    if (!data.error) {
      // Pre-populate first_name and last_name from full_name if empty
      if (data.full_name && !data.first_name && !data.last_name) {
        const parts = data.full_name.trim().split(/\s+/);
        data.first_name = parts[0] || "";
        data.last_name = parts.slice(1).join(" ") || "";
      }
      setProfile(data);
      setOriginalProfile(structuredClone(data));
    } else {
      setFetchError(true);
    }
    setLoading(false);
  }

  useEffect(() => {
    fetchProfile();
  }, []);

  // Scrollspy logic to highlight active sidebar item using IntersectionObserver
  useEffect(() => {
    if (loading) return;
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
        if (visible.length > 0) {
          setActiveSection(visible[0].target.id);
        }
      },
      { rootMargin: "-20% 0px -60% 0px", threshold: 0 }
    );
    SECTIONS.forEach(({ id }) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, [loading]);

  const handleChange = <K extends keyof Profile>(field: K, value: Profile[K]) => {
    setProfile((prev) => {
      if (!prev) return null;
      const updated: Profile = { ...prev, [field]: value };

      if (field === "first_name" || field === "middle_name" || field === "last_name") {
        const fname = field === "first_name" ? (value as string) : (prev.first_name || "");
        const mname = field === "middle_name" ? (value as string) : (prev.middle_name || "");
        const lname = field === "last_name" ? (value as string) : (prev.last_name || "");
        updated.full_name = [fname, mname, lname].filter(Boolean).join(" ");
      }
      return updated;
    });
  };

  // Debounced dirty state checker to avoid lags during rapid typing
  useEffect(() => {
    if (dirtyCheckTimerRef.current) {
      clearTimeout(dirtyCheckTimerRef.current);
    }
    dirtyCheckTimerRef.current = setTimeout(() => {
      setHasUnsavedChanges(isProfileDirty(profile, originalProfile));
    }, 300);
    return () => {
      if (dirtyCheckTimerRef.current) {
        clearTimeout(dirtyCheckTimerRef.current);
      }
    };
  }, [profile, originalProfile]);

  const handleSave = async () => {
    if (!profile) return;
    setIsSaving(true);
    const result = await updateCandidateProfileAction(profile);
    if (result.success) {
      setOriginalProfile(structuredClone(profile));
      setHasUnsavedChanges(false);
      setToast({ message: "Profile updated successfully!", type: "success" });
    } else {
      setToast({ message: result.error || "Failed to save profile", type: "error" });
    }
    setIsSaving(false);
  };

  const handleDiscard = () => {
    if (originalProfile) {
      setProfile(structuredClone(originalProfile));
      setHasUnsavedChanges(false);
      setToast({ message: "Changes discarded", type: "success" });
    }
  };

  // Memoized section statuses
  const sectionStatuses = useMemo(() => {
    const getStatus = (id: string): { status: "complete" | "partial" | "empty"; error: boolean } => {
      if (!profile) return { status: "empty", error: false };
      switch (id) {
        case "personal": {
          const hasRequired = !!(profile.first_name && profile.last_name && profile.email && profile.phone);
          const hasAny = !!(
            profile.first_name ||
            profile.middle_name ||
            profile.last_name ||
            profile.email ||
            profile.phone ||
            profile.whatsapp_number ||
            profile.location ||
            profile.city ||
            profile.country ||
            profile.hometown ||
            profile.pincode
          );
          if (hasRequired) return { status: "complete", error: false };
          if (hasAny) return { status: "partial", error: true };
          return { status: "empty", error: true };
        }
        case "about": {
          const bioLen = profile.bio?.length || 0;
          if (bioLen >= 80) return { status: "complete", error: false };
          if (bioLen > 0) return { status: "partial", error: false };
          return { status: "empty", error: false };
        }
        case "preferences": {
          const hasRequired = !!(profile.desired_titles && profile.expected_salary);
          const hasAny = !!(
            profile.desired_titles ||
            profile.expected_salary ||
            profile.functional_area ||
            profile.industry ||
            profile.notice_period ||
            profile.preferred_locations ||
            profile.work_mode
          );
          if (hasRequired) return { status: "complete", error: false };
          if (hasAny) return { status: "partial", error: false };
          return { status: "empty", error: false };
        }
        case "experience": {
          const hasEntries = !!(profile.experience && profile.experience.length > 0);
          const started = !!profile.experience_years;
          if (hasEntries) return { status: "complete", error: false };
          if (started) return { status: "partial", error: false };
          return { status: "empty", error: false };
        }
        case "education": {
          const hasEntries = !!(profile.education && profile.education.length > 0);
          if (hasEntries) return { status: "complete", error: false };
          return { status: "empty", error: false };
        }
        case "skills": {
          const skillsCount = profile.skills?.length || 0;
          if (skillsCount >= 3) return { status: "complete", error: false };
          if (skillsCount > 0) return { status: "partial", error: false };
          return { status: "empty", error: false };
        }
        case "projects": {
          const hasEntries = !!(profile.projects && profile.projects.length > 0);
          if (hasEntries) return { status: "complete", error: false };
          return { status: "empty", error: false };
        }
        case "certifications": {
          const hasEntries = !!(profile.certifications && profile.certifications.length > 0);
          if (hasEntries) return { status: "complete", error: false };
          return { status: "empty", error: false };
        }
        case "resume": {
          const hasResume = !!profile.resume_file_url;
          if (hasResume) return { status: "complete", error: false };
          return { status: "empty", error: false };
        }
        case "privacy": {
          const hasPrivacy = !!profile.privacy_settings;
          if (hasPrivacy) return { status: "complete", error: false };
          return { status: "empty", error: false };
        }
        default:
          return { status: "empty", error: false };
      }
    };

    const statuses: Record<string, { status: "complete" | "partial" | "empty"; error: boolean }> = {};
    SECTIONS.forEach((sect) => {
      statuses[sect.id] = getStatus(sect.id);
    });
    return statuses;
  }, [profile]);

  // Calculate completeness percentage using weighted logic
  const completenessScore = useMemo(() => {
    let score = 0;
    if (sectionStatuses["personal"]?.status === "complete") score += 20;
    else if (sectionStatuses["personal"]?.status === "partial") score += 10;

    if (sectionStatuses["about"]?.status === "complete") score += 5;
    else if (sectionStatuses["about"]?.status === "partial") score += 2;

    if (sectionStatuses["preferences"]?.status === "complete") score += 5;
    else if (sectionStatuses["preferences"]?.status === "partial") score += 2;

    if (sectionStatuses["experience"]?.status === "complete") score += 20;
    else if (sectionStatuses["experience"]?.status === "partial") score += 10;

    if (sectionStatuses["education"]?.status === "complete") score += 10;

    if (sectionStatuses["skills"]?.status === "complete") score += 15;
    else if (sectionStatuses["skills"]?.status === "partial") score += 7;

    if (sectionStatuses["projects"]?.status === "complete") score += 10;

    if (sectionStatuses["certifications"]?.status === "complete") score += 5;

    if (sectionStatuses["resume"]?.status === "complete") score += 5;

    if (sectionStatuses["privacy"]?.status === "complete") score += 5;

    return score;
  }, [sectionStatuses]);

  if (fetchError) {
    return (
      <main className="flex-1 overflow-y-auto px-4 py-8 md:px-10 md:py-12 h-[calc(100vh-73px)] bg-slate-50/50 flex items-center justify-center">
        <div className="max-w-md w-full bg-white rounded-2xl p-6 border border-slate-200 shadow-sm text-center space-y-4">
          <div className="w-12 h-12 rounded-xl bg-red-50 text-red-500 flex items-center justify-center mx-auto">
            <span className="material-symbols-outlined text-2xl font-bold">error</span>
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-800">Failed to load profile</h3>
            <p className="text-sm text-slate-500 mt-1">
              There was a problem retrieving your candidate profile. Please check your network connection and try again.
            </p>
          </div>
          <button
            type="button"
            onClick={fetchProfile}
            className="w-full py-2.5 bg-primary text-white text-sm font-bold rounded-xl hover:bg-primary/95 transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer min-h-[44px]"
          >
            <span className="material-symbols-outlined text-lg">refresh</span>
            Try Again
          </button>
        </div>
      </main>
    );
  }

  if (loading && !profile) {
    return (
      <main className="flex-1 overflow-y-auto px-4 py-8 md:px-10 md:py-12 h-[calc(100vh-73px)] animate-pulse bg-slate-50/50">
        <div className="max-w-7xl mx-auto space-y-12">
          <div className="h-10 w-48 bg-slate-250 rounded-2xl"></div>
          <div className="grid grid-cols-1 lg:grid-cols-[260px_1fr_320px] gap-8">
            <div className="h-64 bg-slate-250 rounded-2xl"></div>
            <div className="space-y-6">
              <div className="h-80 bg-slate-250 rounded-2xl"></div>
              <div className="h-80 bg-slate-250 rounded-2xl"></div>
            </div>
            <div className="h-96 bg-slate-250 rounded-2xl"></div>
          </div>
        </div>
      </main>
    );
  }

  return (
    <>
      <UnsavedChangesBar 
        isVisible={hasUnsavedChanges} 
        onSave={handleSave} 
        onDiscard={handleDiscard} 
      />
      <main className="flex-1 overflow-y-auto px-4 pt-8 pb-32 md:px-10 md:py-12 h-[calc(100vh-73px)] custom-scrollbar bg-slate-50/30">
        <div className="max-w-7xl mx-auto animate-fade-in">
          {/* Header Toolbar */}
          <div className="flex flex-wrap items-center justify-between mb-8 gap-6">
            <div>
              <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight leading-none mb-2">Edit Profile</h2>
              <p className="text-slate-500 font-medium text-xs sm:text-sm">Create a complete professional profile to get discovered by premium recruiters.</p>
            </div>
            <div className="flex items-center gap-3">
              {hasUnsavedChanges && (
                <>
                  <button 
                    onClick={handleDiscard}
                    className="px-5 py-2.5 rounded-xl bg-white text-slate-600 font-bold text-xs border border-slate-200 hover:bg-slate-50 hover:text-slate-800 transition-all min-h-[44px] flex items-center justify-center cursor-pointer shadow-sm"
                  >
                    Discard Draft
                  </button>
                  <button 
                    onClick={handleSave}
                    className="px-6 py-2.5 rounded-xl bg-primary text-white font-bold text-xs transition-all shadow-sm hover:bg-primary/95 flex items-center gap-2 min-h-[44px] justify-center cursor-pointer"
                  >
                    {isSaving ? "Saving..." : "Save Draft"}
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Three Column Responsive Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-[240px_1fr] xl:grid-cols-[260px_1fr_320px] gap-8 items-start">
            
            {/* Left Sidebar Navigation (Desktop only) */}
            <aside className="hidden lg:block sticky top-24 bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm space-y-4">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Profile Sections</h4>
              <nav className="space-y-1">
                {SECTIONS.map((sect) => {
                  const status = sectionStatuses[sect.id] || { status: "empty", error: false };
                  const isActive = activeSection === sect.id;
                  return (
                    <button
                      key={sect.id}
                      onClick={() => handleNavClick(sect.id)}
                      aria-current={isActive ? "location" : undefined}
                      aria-label={`${sect.label} section`}
                      className={`w-full flex items-center justify-between p-2.5 rounded-xl text-left transition-all cursor-pointer ${
                        isActive 
                          ? "bg-primary/5 text-primary font-bold" 
                          : "text-slate-500 hover:bg-slate-50 hover:text-slate-800 font-medium"
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="material-symbols-outlined text-lg">{sect.icon}</span>
                        <span className="text-xs">{sect.label}</span>
                      </div>
                      
                      <div className="flex items-center gap-1">
                        {status.status === "complete" ? (
                          <span className="material-symbols-outlined text-base text-emerald-500 font-bold">check_circle</span>
                        ) : status.status === "partial" ? (
                          <span className="w-2.5 h-2.5 rounded-full bg-amber-400 shadow-sm" title="Partially Complete"></span>
                        ) : status.error ? (
                          <span className="w-2.5 h-2.5 rounded-full bg-red-400" title="Required Fields Missing"></span>
                        ) : null}
                      </div>
                    </button>
                  );
                })}
              </nav>
            </aside>

            {/* Mobile Bottom Navigation bar (Visible below lg screen size) */}
            <div className="lg:hidden fixed bottom-6 left-4 right-4 z-50 bg-white/90 backdrop-blur-md rounded-2xl p-2 border border-slate-200 shadow-lg flex items-center overflow-x-auto gap-2 no-scrollbar scroll-smooth" style={{ msOverflowStyle: 'none', scrollbarWidth: 'none' }}>
              {SECTIONS.map((sect) => {
                const status = sectionStatuses[sect.id] || { status: "empty", error: false };
                const isActive = activeSection === sect.id;
                return (
                  <button
                    key={sect.id}
                    onClick={() => handleNavClick(sect.id)}
                    aria-current={isActive ? "location" : undefined}
                    aria-label={`${sect.label} section`}
                    className={`flex-shrink-0 flex flex-col items-center justify-center gap-0.5 p-2 rounded-xl w-16 text-slate-500 hover:text-primary transition-all cursor-pointer relative min-h-[44px] ${
                      isActive ? "text-primary font-bold scale-105 bg-primary/5" : ""
                    }`}
                  >
                    <div className="relative">
                      <span className="material-symbols-outlined text-lg">{sect.icon}</span>
                      {status.status === "complete" ? (
                        <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-500 border border-white"></span>
                      ) : status.status === "partial" ? (
                        <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-amber-400 border border-white"></span>
                      ) : status.error ? (
                        <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-red-400 border border-white"></span>
                      ) : null}
                    </div>
                    <span className="text-[10px] font-semibold truncate w-full text-center">{sect.label.split(" ")[0]}</span>
                  </button>
                );
              })}
            </div>

            {/* Center column: Form Editing Area */}
            <div className="space-y-8 min-w-0">
              <ProfileInfoCard 
                profile={profile} 
                onEdit={() => handleNavClick("personal")} 
              />

              <div className="space-y-8">
                <PersonalInfoSection 
                  profile={profile} 
                  onChange={handleChange} 
                  isExpanded={expandedSections.personal}
                  onToggleExpand={() => handleSectionToggle("personal")}
                />

                <AboutMeSection 
                  data={{ bio: profile?.bio }}
                  onChange={(field, val) => handleChange(field, val)}
                  isExpanded={expandedSections.about}
                  onToggleExpand={() => handleSectionToggle("about")}
                />

                <JobPreferencesSection 
                  data={profile || {}}
                  onChange={handleChange}
                  isExpanded={expandedSections.preferences}
                  onToggleExpand={() => handleSectionToggle("preferences")}
                />

                <WorkExperienceSection 
                  data={profile?.experience || []} 
                  onChange={(val) => handleChange("experience", val)}
                  isExpanded={expandedSections.experience}
                  onToggleExpand={() => handleSectionToggle("experience")}
                />

                <EducationSection 
                  data={profile?.education || []} 
                  onChange={(val) => handleChange("education", val)}
                  isExpanded={expandedSections.education}
                  onToggleExpand={() => handleSectionToggle("education")}
                />

                <SkillsSection 
                  data={profile?.skills || []} 
                  onChange={(val) => handleChange("skills", val)}
                  isExpanded={expandedSections.skills}
                  onToggleExpand={() => handleSectionToggle("skills")}
                />

                <ProjectsSection 
                  projects={profile?.projects || []}
                  onChange={(val) => handleChange("projects", val)}
                  isExpanded={expandedSections.projects}
                  onToggleExpand={() => handleSectionToggle("projects")}
                />

                <CertificationsSection 
                  certifications={profile?.certifications || []}
                  onChange={(val) => handleChange("certifications", val)}
                  isExpanded={expandedSections.certifications}
                  onToggleExpand={() => handleSectionToggle("certifications")}
                />

                <ResumeBuilderSection 
                  profile={profile}
                  onChange={handleChange}
                  isExpanded={expandedSections.resume}
                  onToggleExpand={() => handleSectionToggle("resume")}
                />

                <PrivacySettingsSection 
                  privacySettings={profile?.privacy_settings || {}}
                  onChange={(val) => handleChange("privacy_settings", val)}
                  isExpanded={expandedSections.privacy}
                  onToggleExpand={() => handleSectionToggle("privacy")}
                />
              </div>
            </div>

            {/* Right Sticky Sidebar: Completeness Widget & Visibility Index */}
            <aside className="hidden xl:block sticky top-24 space-y-6">
              {/* Profile Completeness Card */}
              <div className="bg-white rounded-2xl p-5 border border-slate-200/85 shadow-sm text-center space-y-5">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Profile Completeness</h4>
                
                {/* SVG Progress Ring */}
                <div className="relative w-28 h-28 mx-auto flex items-center justify-center">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                    <circle
                      cx="50"
                      cy="50"
                      r="40"
                      stroke="#f1f5f9"
                      strokeWidth="6"
                      fill="transparent"
                    />
                    <circle
                      cx="50"
                      cy="50"
                      r="40"
                      stroke="url(#progressGradient)"
                      strokeWidth="6"
                      fill="transparent"
                      strokeDasharray={2 * Math.PI * 40}
                      strokeDashoffset={2 * Math.PI * 40 * (1 - completenessScore / 100)}
                      strokeLinecap="round"
                      className="transition-all duration-700 ease-out"
                    />
                    <defs>
                      <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#4f46e5" />
                        <stop offset="100%" stopColor="#10b981" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <div className="absolute flex flex-col items-center">
                    <span className="text-2xl font-bold text-slate-800">{completenessScore}%</span>
                    <span className="text-xs font-bold uppercase text-slate-500 tracking-wider">Completeness</span>
                  </div>
                </div>

                <div className="space-y-2.5 text-left pt-2 border-t border-slate-100">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Recommended Actions</span>
                  <div className="space-y-1.5">
                    {completenessScore < 100 ? (
                      <>
                        {sectionStatuses["resume"]?.status !== "complete" && (
                          <button
                            onClick={() => handleNavClick("resume")}
                            className="w-full text-left p-2 bg-slate-50 hover:bg-slate-100 rounded-lg text-xs font-semibold text-slate-600 flex items-center gap-2 cursor-pointer transition-colors"
                          >
                            <span className="material-symbols-outlined text-xs text-primary font-bold">add</span>
                            Upload resume (+5%)
                          </button>
                        )}
                        {sectionStatuses["experience"]?.status !== "complete" && (
                          <button
                            onClick={() => handleNavClick("experience")}
                            className="w-full text-left p-2 bg-slate-50 hover:bg-slate-100 rounded-lg text-xs font-semibold text-slate-600 flex items-center gap-2 cursor-pointer transition-colors"
                          >
                            <span className="material-symbols-outlined text-xs text-primary font-bold">add</span>
                            Add Work Experience (+20%)
                          </button>
                        )}
                        {sectionStatuses["skills"]?.status !== "complete" && (
                          <button
                            onClick={() => handleNavClick("skills")}
                            className="w-full text-left p-2 bg-slate-50 hover:bg-slate-100 rounded-lg text-xs font-semibold text-slate-600 flex items-center gap-2 cursor-pointer transition-colors"
                          >
                            <span className="material-symbols-outlined text-xs text-primary font-bold">add</span>
                            Add 3 skills (+15%)
                          </button>
                        )}
                      </>
                    ) : (
                      <div className="p-2.5 bg-emerald-50 rounded-xl text-center text-xs font-bold text-emerald-600 border border-emerald-100 flex items-center justify-center gap-1.5">
                        <span className="material-symbols-outlined text-base">verified</span>
                        Profile fully complete!
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Profile Visibility Level (Non-fabricated benchmarking description) */}
              <div className="bg-white rounded-2xl p-5 border border-slate-250 shadow-sm space-y-4">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-indigo-600 font-bold text-lg">visibility</span>
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Recruiter Discoverability</span>
                </div>
                <div>
                  <h4 className="text-base font-bold text-slate-800">
                    {completenessScore < 40 ? "Needs Profile Setup" : completenessScore < 75 ? "Good Search Presence" : "Excellent Discoverability"}
                  </h4>
                  <p className="text-xs text-slate-500 leading-relaxed mt-1">
                    {completenessScore < 40 
                      ? "Complete key details like work history and skills to increase your visibility to recruiters." 
                      : completenessScore < 75 
                        ? "Your profile is visible in recruiter searches. Complete remaining sections to reach top priority." 
                        : "Outstanding! Your profile is fully optimized and prioritized in recruiter candidate feeds."}
                  </p>
                </div>
                <button
                  onClick={() => handleNavClick("resume")}
                  className="w-full py-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer"
                >
                  Configure Resume Builder
                </button>
              </div>
            </aside>
          </div>
        </div>

        {toast && (
          <Toast 
            message={toast.message} 
            type={toast.type} 
            onClose={() => setToast(null)} 
          />
        )}
      </main>
    </>
  );
}
